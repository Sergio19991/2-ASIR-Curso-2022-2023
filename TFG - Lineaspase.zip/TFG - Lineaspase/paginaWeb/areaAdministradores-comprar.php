<?php include "conexionBD.php"; ?>

<?php
session_start();

if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
    $nombre = $_SESSION["nombre"];
    $nombreUsuario = $_SESSION["nombreUsuario"];
    $primerApellido = $_SESSION["primerApellido"];
    $segundoApellido = $_SESSION["segundoApellido"];
    $dni = $_SESSION["dni"];
} else {
    header("Location: iniciarSesion.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Comprar Billete</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/comprar.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php">USUARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-flota.php">FLOTA</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="contenidoPrincipal">
            <?php
                function limpiarCaracteres($datos) {
                    $datos = trim($datos);
                    $datos = stripslashes($datos);
                    $datos = htmlspecialchars($datos);
                    return $datos;
                }

                if (isset($_GET['codigoLineaURL'])) {
                    $codigoLineaURLObtenido = limpiarCaracteres($_GET['codigoLineaURL']);
                }

                /* Consulta para los Datos de la Línea pasada por URL: */
                $consultarLineas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lineas.hora_salida AS 'horaSalida', lineas.hora_llegada AS 'horaLlegada', lo.nombre AS 'nombreLocalidadOrigen', lo.ciudad AS 'nombreCiudadOrigen', ld.nombre AS 'nombreLocalidadDestino', ld.ciudad AS 'nombreCiudadDestino', billetes.stock AS 'stock', billetes.precio_venta AS 'precio'
                                    FROM lineas
                                    JOIN lineas llo ON llo.codigo = lineas.codigo
                                    JOIN localidad lo ON lo.codigo = llo.localidad_origen
                                    JOIN lineas lld ON lld.codigo = lineas.codigo
                                    JOIN localidad ld ON ld.codigo = lld.localidad_destino
                                    JOIN billetes on lineas.codigo = billetes.codigo_linea
                                    WHERE lineas.codigo = {$codigoLineaURLObtenido}";

                $resultadoConsultarLineas = mysqli_query($enlace, $consultarLineas);

                if ($resultadoConsultarLineas) {
                    $fila = mysqli_fetch_assoc($resultadoConsultarLineas);

                    $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                    $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                    $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                    $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                    $nombreLocalidadOrigen = mysqli_real_escape_string($enlace, $fila['nombreLocalidadOrigen']);
                    $nombreCiudadOrigen = mysqli_real_escape_string($enlace, $fila['nombreCiudadOrigen']);
                    $nombreLocalidadDestino = mysqli_real_escape_string($enlace, $fila['nombreLocalidadDestino']);
                    $nombreCiudadDestino = mysqli_real_escape_string($enlace, $fila['nombreCiudadDestino']);
                    $stock = mysqli_real_escape_string($enlace, $fila['stock']);
                    $precio = mysqli_real_escape_string($enlace, $fila['precio']);
                }

                /* Consulta para obtener todas las Horas de Salida en Orden Ascendente. */
                $consultarHorasSalida = "SELECT lineas.hora_salida AS 'horasSalida'
                                         FROM lineas
                                         WHERE lineas.nombre = (SELECT lineas.nombre FROM lineas WHERE lineas.codigo = {$codigoLineaURLObtenido})
                                         ORDER BY lineas.hora_salida ASC";
                $resultadoConsultarHorasSalida = mysqli_query($enlace, $consultarHorasSalida);
                $arrayHorasSalida = array();
                if ($resultadoConsultarHorasSalida) {
                    while ($fila = mysqli_fetch_assoc($resultadoConsultarHorasSalida)) {
                        $arrayHorasSalida[] = mysqli_real_escape_string($enlace, $fila['horasSalida']);
                    }
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    /* Consulta para los Datos de la Línea pasada por URL: */
                    $codigoLineaURLObtenido = limpiarCaracteres($_POST['codigoLineaURL']);
                    $consultarLineas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lineas.hora_salida AS 'horaSalida', lineas.hora_llegada AS 'horaLlegada', lo.nombre AS 'nombreLocalidadOrigen', lo.ciudad AS 'nombreCiudadOrigen', ld.nombre AS 'nombreLocalidadDestino', ld.ciudad AS 'nombreCiudadDestino', billetes.stock AS 'stock', billetes.precio_venta AS 'precio'
                                        FROM lineas
                                        JOIN lineas llo ON llo.codigo = lineas.codigo
                                        JOIN localidad lo ON lo.codigo = llo.localidad_origen
                                        JOIN lineas lld ON lld.codigo = lineas.codigo
                                        JOIN localidad ld ON ld.codigo = lld.localidad_destino
                                        JOIN billetes on lineas.codigo = billetes.codigo_linea
                                        WHERE lineas.codigo = {$codigoLineaURLObtenido}";

                    $resultadoConsultarLineas = mysqli_query($enlace, $consultarLineas);

                    if ($resultadoConsultarLineas) {
                        $fila = mysqli_fetch_assoc($resultadoConsultarLineas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        $nombreLocalidadOrigen = mysqli_real_escape_string($enlace, $fila['nombreLocalidadOrigen']);
                        $nombreCiudadOrigen = mysqli_real_escape_string($enlace, $fila['nombreCiudadOrigen']);
                        $nombreLocalidadDestino = mysqli_real_escape_string($enlace, $fila['nombreLocalidadDestino']);
                        $nombreCiudadDestino = mysqli_real_escape_string($enlace, $fila['nombreCiudadDestino']);
                        $stock = mysqli_real_escape_string($enlace, $fila['stock']);
                        $precio = mysqli_real_escape_string($enlace, $fila['precio']);
                    }

                    /* Datos recopilados del Formulario: */
                    $fechaSeleccionada = limpiarCaracteres($_POST['fechaSeleccionada']);
                    $horaSeleccionada = limpiarCaracteres($_POST['horaSeleccionada']);
                    $cantidadSeleccionada = limpiarCaracteres($_POST['cantidadSeleccionada']);
                    
                    $fechaActual = date('Y-m-d');
                    if ($fechaSeleccionada < $fechaActual) {
                        $mensajeErrorFecha = "*La Fecha seleccionada no puede ser anterior a la de hoy.";
                    }
                    if (empty($fechaSeleccionada)) {
                        $mensajeErrorFecha = "*No ha seleccionado ninguna Fecha.";
                    }

                    $consultarHorasSalida = "SELECT lineas.hora_salida AS 'horasSalida'
                                             FROM lineas
                                             WHERE lineas.nombre = (SELECT lineas.nombre FROM lineas WHERE lineas.codigo = {$codigoLineaURLObtenido})
                                             ORDER BY lineas.hora_salida ASC";
                    $resultadoConsultarHorasSalida = mysqli_query($enlace, $consultarHorasSalida);
                    $arrayHorasSalida = array();
                    if ($resultadoConsultarHorasSalida) {
                        while ($fila = mysqli_fetch_assoc($resultadoConsultarHorasSalida)) {
                            $arrayHorasSalida[] = mysqli_real_escape_string($enlace, $fila['horasSalida']);
                        }
                    }

                    $horaActual = date('H:i:s');
                    if ($fechaSeleccionada <= $fechaActual && $horaSeleccionada <= $horaActual) {
                        $mensajeErrorHora = "*La Hora seleccionadas debe ser posterior a la actual.";
                    }

                    $cantidadMaximaPermitida = "100";
                    if ($cantidadSeleccionada > $stock) {
                        $mensajeErroCantidadSrock = "*Lo sentimos, la cantidad de Billetes seleccionada no está disponible.";
                    }

                    $precioTotal = $cantidadSeleccionada * $precio;

                    $consultarCondigoLineaParaURL = "SELECT lineas.codigo AS 'codigoLineaURL'
                                                     FROM lineas
                                                     WHERE lineas.codigo = (
                                                         SELECT lineas.codigo
                                                         FROM lineas
                                                         WHERE lineas.hora_salida LIKE '{$horaSeleccionada}' AND lineas.nombre = (
                                                             SELECT lineas.nombre
                                                             FROM lineas
                                                             WHERE lineas.codigo = {$codigoLineaURLObtenido}
                                                         )
                                                     )";
                   $resultadoConsultarCondigoLineaParaURL = mysqli_query($enlace, $consultarCondigoLineaParaURL);

                   if ($resultadoConsultarCondigoLineaParaURL) {
                       $fila = mysqli_fetch_assoc($resultadoConsultarCondigoLineaParaURL);
                       $condigoLineaParaURL = mysqli_real_escape_string($enlace, $fila['codigoLineaURL']);
                   }

                    if ((empty($mensajeErrorFecha)) && (empty($mensajeErrorHora)) && (empty($mensajeErroCantidadSrock))) {
                        header("Location: areaAdministradores-pagar.php?codigoLineaURL={$condigoLineaParaURL}&fechaSeleccionadaURL={$fechaSeleccionada}&horaSeleccionadaURL={$horaSeleccionada}&cantidadSeleccionadaURL={$cantidadSeleccionada}");
                    }
                }
            ?>

            <h1>COMPRAR BILLETE</h1>

            <div class='titulo'> <?php echo "{$nombreLinea}: {$nombreLocalidadOrigen}({$nombreCiudadOrigen}) - {$nombreLocalidadDestino}({$nombreCiudadDestino})" ?> </div>
            <div class='contenido'>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <input type="hidden" name="codigoLineaURL" value="<?php echo $codigoLineaURLObtenido; ?>">

                    <label for="fechaSeleccionada">Seleccione la Fecha:</label>
                    <input type="date" name="fechaSeleccionada" id="fechaSeleccionada" value="<?php echo isset($_POST['fechaSeleccionada']) ? $_POST['fechaSeleccionada'] : $fechaSeleccionada; ?>"> <br>
                    <input type="hidden" name="fechaSeleccionada_hidden" value="<?php echo $fechaSeleccionada; ?>">
                    <?php
                        if (!empty($mensajeErrorFecha)) {
                            echo '<span class="mensajeErrorFecha">' . $mensajeErrorFecha . '</span> <br>';
                        }
                    ?>

                    <label for="horaSeleccionada">Seleccione la Hora:</label>
                    <select name="horaSeleccionada" id="horaSeleccionada">';
                    <?php
                        foreach ($arrayHorasSalida as $horasSalida) {
                            if ($horasSalida === $horaSeleccionada) {
                                echo "<option value=\"$horasSalida\" selected>$horasSalida</option>";
                            } else {
                                echo "<option value=\"$horasSalida\">$horasSalida</option>";
                            }
                        }
                    ?>
                    </select> <br>
                    <?php
                        if (!empty($mensajeErrorHora)) {
                            echo '<span class="mensajeErrorHora">' . $mensajeErrorHora . '</span> <br>';
                        }
                    ?>

                    <label for="cantidadSeleccionada">Seleccione la Cantidad:</label>
                    <input type="number" name="cantidadSeleccionada" id="cantidadSeleccionada" min="1" max="<?php echo $cantidadMaximaPermitida; ?>" value="<?php echo isset($_POST['cantidadSeleccionada']) ? $_POST['cantidadSeleccionada'] : '1'; ?>"> <br>
                    <?php
                        if (!empty($mensajeErroCantidadSrock)) {
                            echo '<span class="mensajeErroCantidadSrock">' . $mensajeErroCantidadSrock . '</span> <br>';
                        }
                    ?>

                    <br> <input type="submit" value="Confirmar" title="Continuar con el Método de Pago.">
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php" class="botonVolver" title="Volver a Rutas y Horarios">Cancelar y Volver</a> <br>
                </form>
            </div>
        </div>
    </main>
    <footer>
        <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
    </footer>
</body>

</html>

<?php
    mysqli_close($enlace);
?>