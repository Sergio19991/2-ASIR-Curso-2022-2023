<?php
    session_start();
    session_destroy();
    setcookie('rol', '', time() - 3600, '/');
    header("Location: https://www.lineaspase.com/iniciarSesion.php");

    mysqli_close($enlace);
    
    exit();
?>