<?php include "conexionBD.php"; ?>

<?php
session_start();

if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
    $nombre = $_SESSION["nombre"];
    $nombreUsuario = $_SESSION["nombreUsuario"];
    $primerApellido = $_SESSION["primerApellido"];
    $segundoApellido = $_SESSION["segundoApellido"];
    $dni = $_SESSION["dni"];
} else {
    header("Location: iniciarSesion.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Pagar Billete</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/pagar.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/formatosMetodosPago.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php">USUARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-flota.php">FLOTA</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="contenidoPrincipal">
            <?php
                function limpiarCaracteres($datos) {
                    $datos = trim($datos);
                    $datos = stripslashes($datos);
                    $datos = htmlspecialchars($datos);
                    return $datos;
                }

                if (isset($_GET['codigoLineaURL']) && (isset($_GET['fechaSeleccionadaURL'])) && (isset($_GET['horaSeleccionadaURL'])) && (isset($_GET['cantidadSeleccionadaURL']))) {
                    $codigoLineaURLObtenido = limpiarCaracteres($_GET['codigoLineaURL']);
                    $fechaSeleccionadaURLObtenido = limpiarCaracteres($_GET['fechaSeleccionadaURL']);
                    $horaSeleccionadaLineaURLObtenido = limpiarCaracteres($_GET['horaSeleccionadaURL']);
                    $cantidadSeleccionadaURLObtenido = limpiarCaracteres($_GET['cantidadSeleccionadaURL']);
                }
                
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $numeroTarjeta = limpiarCaracteres($_POST["numeroTarjeta"]);
                    $fechaExpiracion = limpiarCaracteres($_POST["fechaExpiracion"]);
                    $codigoSeguridad = limpiarCaracteres($_POST["codigoSeguridad"]);
                    $titularTarjeta = limpiarCaracteres($_POST["titularTarjeta"]);
                    $aceptarTerminos = limpiarCaracteres($_POST["aceptarTerminos"]);

                    $codigoLineaURLObtenido = limpiarCaracteres($_POST["codigoLineaURLObtenido"]);
                    $fechaSeleccionadaURLObtenido = limpiarCaracteres($_POST["fechaSeleccionadaURLObtenido"]);
                    $horaSeleccionadaLineaURLObtenido = limpiarCaracteres($_POST["horaSeleccionadaLineaURLObtenido"]);
                    $cantidadSeleccionadaURLObtenido = limpiarCaracteres($_POST["cantidadSeleccionadaURLObtenido"]);

                    if (empty($numeroTarjeta)) {
                        $mensajeErrorNumeroTarjeta = "*Debes introducir el Número de la Tarjeta.";
                    } elseif (strlen($numeroTarjeta) < 19) {
                        $mensajeErrorNumeroTarjeta = "*El Número de Tarjeta introducido no es válido.";
                    }
                    
                    $fechaActual = date("m/Y");
                    $fechaExpiracionArr = explode("/", $fechaExpiracion);
                    if (empty($fechaExpiracion)) {
                        $mensajeErrorFechaExpiracion .= "*Debes introducir la Fecha de Expiración.";
                    } else {
                        $fechaExpiracionArr = explode("/", $fechaExpiracion);
                    
                        if (count($fechaExpiracionArr) != 2) {
                            $mensajeErrorFechaExpiracion .= "*La Fecha de Expiración es inválida.";
                        } else {
                            $mesExpiracion = intval($fechaExpiracionArr[0]);
                            $anoExpiracion = intval($fechaExpiracionArr[1]);
                    
                            $anioActual = intval(date('y'));
                            $mesActual = intval(date('m'));
                    
                            if ($anoExpiracion < $anioActual || ($anoExpiracion == $anioActual && $mesExpiracion < $mesActual)) {
                                $mensajeErrorFechaExpiracion .= "*La tarjeta ha caducado.";
                            }
                        }
                    }

                    if (empty($codigoSeguridad)) {
                        $mensajeErrorCodigoSeguridad = "*Debes introducir el Código de Seguridad.";
                    } elseif (strlen($codigoSeguridad) < 3) {
                        $mensajeErrorCodigoSeguridad = "*El Código de Seguridad introducido no es válido.";
                    }

                    if (empty($titularTarjeta)) {
                        $mensajeErrorTitularTarjeta = "*Debe escribir el Titular de la Tarjeta.";
                    }

                    if (empty($aceptarTerminos)) {
                        $mensajeErrorAceptarTerminos = "*Debes aceptar los Términos de la Política de Privacidad.";
                    }

                    $consultarNombreLinea = "SELECT lineas.nombre AS 'nombreLinea', billetes.precio_venta AS 'precioVenta'
                                             FROM lineas, billetes
                                             WHERE lineas.codigo = billetes.codigo_linea AND lineas.codigo = {$codigoLineaURLObtenido}";
                    $resultadoConsultarNombreLinea = mysqli_query($enlace, $consultarNombreLinea);
                    if ($resultadoConsultarNombreLinea) {
                        $fila = mysqli_fetch_assoc($resultadoConsultarNombreLinea);

                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $precioVenta = mysqli_real_escape_string($enlace, $fila['precioVenta']);

                        $precioTotal = number_format(($precioVenta * $cantidadSeleccionadaURLObtenido), 2, ',', '.');

                        $fechaObjeto = date_create_from_format('Y-m-d', $fechaSeleccionadaURLObtenido);
                        $fechaFormateada = $fechaObjeto->format('d/m/Y');
                    }

                    if ((!empty($numeroTarjeta) && (!empty($fechaExpiracion)) && (!empty($codigoSeguridad)) && (!empty($titularTarjeta)) && (!empty($aceptarTerminos)))) {
                        $consultaRestarStock = "UPDATE billetes
                                                SET billetes.stock = billetes.stock - {$cantidadSeleccionadaURLObtenido}
                                                WHERE billetes.codigo_linea = {$codigoLineaURLObtenido};";
                        $resultadoConsultaRestarStock = mysqli_query($enlace, $consultaRestarStock);

                        $fechaActualInsertar = date('Y-m-d');
                        $consultaInsertarComprar = "INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ('{$fechaActualInsertar}', {$cantidadSeleccionadaURLObtenido}, (SELECT billetes.codigo FROM billetes WHERE billetes.codigo_linea = {$codigoLineaURLObtenido}), '{$dni}')";
                        $resultadoConsultaInsertarComprar = mysqli_query($enlace, $consultaInsertarComprar);

                        $consultaCodigoComprar = "SELECT comprar.codigo AS 'codigoComprar'
                                                  FROM comprar, clientes
                                                  WHERE comprar.nif_clientes = clientes.nif AND clientes.nif LIKE '{$dni}'
                                                  ORDER BY comprar.codigo DESC
                                                  LIMIT 1";
                        $resultadoConsultaCodigoComprar = mysqli_query($enlace, $consultaCodigoComprar);
                        if ($resultadoConsultaCodigoComprar) {
                            $fila = mysqli_fetch_assoc($resultadoConsultaCodigoComprar);
                            $codigoComprar = mysqli_real_escape_string($enlace, $fila['codigoComprar']);
                        }

                        if ($resultadoConsultaRestarStock && $resultadoConsultaInsertarComprar && $resultadoConsultaCodigoComprar) {
                            $horaCompra = date("H:i:s");
                            header("Location: areaAdministradores-ticket.php?codigoComprar={$codigoComprar}&fechaSeleccionada={$fechaSeleccionadaURLObtenido}&horaCompra={$horaCompra}");
                        } else {
                            $mensajeErrorAlPagar = "*En estos momentos no ha sido posbile realizar la compra. Por favor, vuelva a intentarlo más tarde o póngase en contacto haciendo clic <a href='https://www.lineaspase.com/areaAdministradores-contacto.php'>aquí</a>.";
                        }
                    }
                }
            ?>

            <h1>PAGAR BILLETE</h1>

            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="codigoLineaURLObtenido" value="<?php echo $codigoLineaURLObtenido; ?>">
                <input type="hidden" name="fechaSeleccionadaURLObtenido" value="<?php echo $fechaSeleccionadaURLObtenido; ?>">
                <input type="hidden" name="horaSeleccionadaLineaURLObtenido" value="<?php echo $horaSeleccionadaLineaURLObtenido; ?>">
                <input type="hidden" name="cantidadSeleccionadaURLObtenido" value="<?php echo $cantidadSeleccionadaURLObtenido; ?>">

                <p class="resumenCompra">
                    <?php
                        $consultarNombreLinea = "SELECT lineas.nombre AS 'nombreLinea', billetes.precio_venta AS 'precioVenta'
                                                 FROM lineas, billetes
                                                 WHERE lineas.codigo = billetes.codigo_linea AND lineas.codigo = {$codigoLineaURLObtenido}";
                        $resultadoConsultarNombreLinea = mysqli_query($enlace, $consultarNombreLinea);
                        if ($resultadoConsultarNombreLinea) {
                            $fila = mysqli_fetch_assoc($resultadoConsultarNombreLinea);

                            $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                            $precioVenta = mysqli_real_escape_string($enlace, $fila['precioVenta']);

                            $precioTotal = number_format(($precioVenta * $cantidadSeleccionadaURLObtenido), 2, ',', '.');

                            $fechaObjeto = date_create_from_format('Y-m-d', $fechaSeleccionadaURLObtenido);
                            $fechaFormateada = $fechaObjeto->format('d/m/Y');

                            echo 'Comprar ' . $cantidadSeleccionadaURLObtenido . ' Billetes para el ' . $fechaFormateada . ' - ' . $horaSeleccionadaLineaURLObtenido . ' para la Línea ' . $nombreLinea . ' por ' . $precioTotal . '€ (IVA incluido).';
                        }
                    ?>
                </p>

                <label for="numeroTarjeta">Número de Tarjeta:</label>  <img src="img/visa.svg" alt="visa"> <img src="img/mastercard.svg" alt="mastercard"> <br>
                <input type="text" name="numeroTarjeta" id="numeroTarjeta" maxlength="19" placeholder="XXXX XXXX XXXX XXXX" oninput="formatCreditCardNumber(this)" onkeypress="return onlyNumbers(event)" value="<?php echo $numeroTarjeta; ?>">
                    <img >
                </input>
                <?php
                    if (!empty($mensajeErrorNumeroTarjeta)) {
                        echo '<span class="mensajeErrorNumeroTarjeta">' . $mensajeErrorNumeroTarjeta . '</span> <br>';
                    }
                ?>
                

                <label for="fechaExpiracion">Fecha de Expiración:</label>
                <input type="text" id="fechaExpiracion" name="fechaExpiracion" maxlength="5" onkeypress="return validateDate(event)" placeholder="MM/AA" value="<?php echo $fechaExpiracion; ?>"> <br>
                <?php
                    if (!empty($mensajeErrorFechaExpiracion)) {
                        echo '<span class="mensajeErrorFechaExpiracion">' . $mensajeErrorFechaExpiracion . '</span> <br>';
                    }
                ?>

                <label for="codigoSeguridad">CVC / CVV:</label>
                <input type="text" name="codigoSeguridad" id="codigoSeguridad" maxlength="3" placeholder="XXX" onkeypress="return onlyNumbers(event)" value="<?php echo $codigoSeguridad; ?>"> <br>
                <?php
                    if (!empty($mensajeErrorCodigoSeguridad)) {
                        echo '<span class="mensajeErrorCodigoSeguridad">' . $mensajeErrorCodigoSeguridad . '</span> <br>';
                    }
                ?>

                <label for="titularTarjeta">Titular de la Tarjeta de Crédio o Débito:</label> <br>
                <input type="text" name="titularTarjeta" id="titularTarjeta" placeholder="Nombre del Titular de la Tarjeta." value="<?php echo $titularTarjeta; ?>"> <br>
                <?php
                    if (!empty($mensajeErrorTitularTarjeta)) {
                        echo '<span class="mensajeErrorTitularTarjeta">' . $mensajeErrorTitularTarjeta . '</span> <br>';
                    }
                ?>

                <input type="checkbox" name="aceptarTerminos" id="aceptarTerminos" <?php if ($aceptarTerminos) echo 'checked'; ?> />He leído y estoy de acuerdo con la <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php#aceptoTerminos">Política de Privacidad<a>.</span> <span id="faltaTerminos" class="faltanCampos"></span> <br>
                <?php
                    if (!empty($mensajeErrorAceptarTerminos)) {
                        echo '<span class="mensajeErrorAceptarTerminos">' . $mensajeErrorAceptarTerminos . '</span> <br>';
                    }
                ?>

                <input type="submit" value="Pagar">
                <a href="https://www.lineaspase.com/areaAdministradores-comprar.php?codigoLineaURL=<?php echo $codigoLineaURLObtenido; ?>" class='botonVolver'>Cancelar y Volver</a> <br>

                <?php
                    if (!(empty($mensajeErrorAlPagar))) {
                        echo '<span class="mensajeErrorAlPagar">' . $mensajeErrorAlPagar . '</span>';
                    }
                ?>
            </form>
    </main>
    <footer>
        <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
    </footer>
</body>

</html>

<?php
    mysqli_close($enlace);
?>