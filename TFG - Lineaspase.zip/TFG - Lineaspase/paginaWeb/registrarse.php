<?php include "conexionBD.php"; ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Registrarse</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/registrarse.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/soloNumeros.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/textosLegales.html">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/nosotros.html">NOSOTROS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/iniciarSesion.php" class="paginaActiva">Iniciar sesión</a>
                </li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="contenidoPrincipal">
            <h1>REGÍSTRATE</h1>

            <div class="botonesInicioRegistrarse">
                <a href="https://www.lineaspase.com/iniciarSesion.php">
                     <button class="botonIniciarSesion">Inicia sesión</button>
                </a>
                <a href="https://www.lineaspase.com/registrarse.php">
                    <button class="botonRegistrarse">Regístrate</button>
                </a>
            </div>

            <?php
                error_reporting(E_ALL & ~E_NOTICE);

                $faltaNombre = "";
                $faltaPrimerApellido = "";
                $faltaSegundoApellido = "";
                $faltaDni = "";
                $faltaFechaNacimiento = "";
                $faltaTelefono = "";
                $faltaEmail = "";
                $faltaNombreUsuario = "";
                $faltaContrasena = "";
                $faltaRepetirContrasena = "";
                $faltaAceptarTerminos = "";

                $nombre = "";
                $primerApellido = "";
                $segundoApellido = "";
                $dni = "";
                $fechaNacimiento = "";
                $telefono = "";
                $email = "";
                $nombreUsuario = "";
                $contrasena = "";
                $repetirContrasena = "";
                $aceptarTerminos = "";

                function limpiarCaracteres($datos) {
                    $datos = trim($datos);
                    $datos = stripslashes($datos);
                    $datos = htmlspecialchars($datos);
                    return $datos;
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $aceptarTerminos = "";
                    $nombre = limpiarCaracteres($_POST["nombre"]);
                    $primerApellido = limpiarCaracteres($_POST["primerApellido"]);
                    $segundoApellido = limpiarCaracteres($_POST["segundoApellido"]);
                    $dni = limpiarCaracteres($_POST["dni"]);
                    $fechaNacimiento = limpiarCaracteres($_POST["fechaNacimiento"]);
                    $telefono = limpiarCaracteres($_POST["telefono"]);
                    $email = limpiarCaracteres($_POST["email"]);
                    $nombreUsuario = limpiarCaracteres($_POST["nombreUsuario"]);
                    $contrasena = limpiarCaracteres($_POST["contrasena"]);
                    $repetirContrasena = limpiarCaracteres($_POST["repetirContrasena"]);
                    $aceptarTerminos = limpiarCaracteres($_POST["aceptarTerminos"]);

                    if (empty($nombre)) {
                        $faltaNombre = "*Debes escribir tu Nombre.";
                    } elseif (strlen($nombre) > 25) {
                        $faltaNombreUsuario = "*El Nombre que has introducido no puede contener más de 25 Carácteres.";
                    }

                    if (empty($primerApellido)) {
                        $faltaPrimerApellido = "*Debes escribir tu Primer Apellido.";
                    } elseif (strlen($primerApellido) > 25) {
                        $faltaPrimerApellido = "*El Primer Apellido que has introducido no puede contener más de 25 Carácteres.";
                    }

                    if (empty($segundoApellido)) {
                        $faltaSegundoApellido = "*Debes escribir tu Segundo Apellido.";
                    } elseif (strlen($segundoApellido) > 25) {
                        $faltaSegundoApellido = "*El Segundo Apellido que has introducido no puede contener más de 25 Carácteres.";
                    }

                    $fechaActual = date("Y-m-d");
                    $edad = date_diff(date_create($fechaNacimiento), date_create($fechaActual))->y;

                    if (empty($fechaNacimiento)) {
                        $faltaFechaNacimiento = "*Debes introducir tu Fecha de Nacimiento.";
                    } elseif ($edad < 18) {
                        $faltaFechaNacimiento = "*Debes tener al menos 18 años para poder registrarte.";
                    }

                    if (empty($dni)) {
                        $faltaDni = "*Debes escribir tu DNI.";
                    } elseif (preg_match('/^[0-9]{8}[A-Z]$/', $dni)) {
                        $numero = substr($dni, 0, 8);
                        $letra = strtoupper(substr($dni, -1));
                        $letras_validas = 'TRWAGMYFPDXBNJZSQVHLCKE';
                        $letraCalculada = $letras_validas[$numero % 23];

                        if ($letraCalculada <> $letra) {
                            $faltaDni = "*El DNI que has escrito no es válido.";
                        }
                    } else {
                        $faltaDni = "*El DNI que has escrito no es válido.";
                    }

                    if (empty($telefono)) {
                        $faltaTelefono = "*Debes escribir tu Número de Teléfono.";
                    } elseif (!preg_match("/^[0-9]{9}$/", $telefono)) {
                        $faltaTelefono = "*El Número de Teléfono que has escrito no es válido.";
                    }

                    if (empty($email)) {
                        $faltaEmail = "*Debes escribir tu Correo Electrónico.";
                    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $faltaEmail = "*El Correo Electrónico que has introducido no es válido.";
                    } elseif (strlen($email) > 50) {
                        $faltaEmail = "*El Correo Electrónico que has introducido no puede contener más de 50 Carácteres.";
                    }

                    if (empty($nombreUsuario)) {
                        $faltaNombreUsuario = "*Debes de escribir un Nombre de Usuario.";
                    } elseif (strpos($nombreUsuario, ' ') !== false) {
                        $faltaNombreUsuario = "*El Nombre de Usuario no puede contener espacios.";
                    } elseif (strlen($nombreUsuario) > 20) {
                        $faltaNombreUsuario = "*El Nombre de Usuario que has introducido no puede contenner más de 20 Carácteres.";
                    }

                    if (empty($contrasena)) {
                        $faltaContrasena = "*Debes de escribir una Contraseña.";
                    } elseif ((strlen($contrasena) < 8) || (!preg_match('/[A-Z]/', $contrasena)) || (!preg_match('/[a-z]/', $contrasena)) || (!preg_match('/[0-9]/', $contrasena)) || (!preg_match('/[\W]/', $contrasena))) {
                        $faltaContrasena = "*La Contraseña que has introducido no cumple con los Requisitos Mínimos. (Debe tener, al menos, 8 Dígitos, una Letra Minúscula, una Letra Mayúscula, un Número y un Carácter Especial).";
                    }

                    if (empty($repetirContrasena)) {
                        $faltaRepetirContrasena = "*Debes de introducir la misma Contraseña.";
                    } elseif (!($contrasena === $repetirContrasena)) {
                        $faltaRepetirContrasena = "*Las Contraseñas no coinciden.";
                        $faltaContrasena = "*Las Contraseñas no coinciden.";
                    }

                    if (empty($aceptarTerminos)) {
                        $faltaAceptarTerminos = "*Debes aceptar los Términos de la Política de Privacidad.";
                    }

                    $consultarUsuario = "SELECT nif AS 'dni', nombre_usuario AS 'nombreUsuario' FROM clientes";
                    $resultadoUsuario = mysqli_query($enlace, $consultarUsuario);

                    if (mysqli_num_rows($resultadoUsuario) > 0) {
                        while ($fila = mysqli_fetch_assoc($resultadoUsuario)) {
                            if (mysqli_real_escape_string($enlace, $fila["dni"]) == $dni) {
                                $faltaDni = "*Este DNI ya ha sido registrado anteriormente.";
                            }
                            if (mysqli_real_escape_string($enlace, $fila["nombreUsuario"]) == $nombreUsuario) {
                                $faltaNombreUsuario = "*Este Nombre de Usuario ya ha sido registrado anteriormente.";
                            }
                        }
                    }

                    if ((empty($faltaNombre)) && (empty($faltaPrimerApellido)) && (empty($faltaSegundoApellido)) && (empty($faltaDni)) && (empty($faltaFechaNacimiento)) && (empty($faltaTelefono)) && (empty($faltaEmail)) && (empty($faltaNombreUsuario)) && (empty($faltaContrasena)) && (empty($faltaRepetirContrasena)) && (empty($faltaAceptarTerminos))) {
                        $contrasenaCifrada = md5($contrasena);
                        $insertarUsuario = "INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ('{$dni}', '{$nombre}', '{$primerApellido}', '{$segundoApellido}', '{$fechaNacimiento}', '{$telefono}', '{$email}', '{$nombreUsuario}', '{$contrasenaCifrada}', 'Cliente')";
                        if (mysqli_query($enlace, $insertarUsuario)) {
                            $mensajeRegistrado = "¡Enhorabuena! Te has registrado correctamente.";

                            $destinatario = $email;
                            $encabezado = '!BIENVENID@¡:';
                            $cuerpoMensaje = 'Bienvedid@ a Lineaspase. Gracias por registrarte.';
                            $headers = 'From: lineaspase@lineaspase.com' . "\r\n" .
                                       'Reply-To: lineaspase@lineaspase.com' . "\r\n" .
                                       'X-Mailer: PHP/' . phpversion();
                            mail($destinatario, $encabezado, $cuerpoMensaje, $headers);
                        } else {
                            $mensajeNoRegistrado = "*No ha sido posbile registrar sus datos en estos momentos. Por favor, vuelva a intentarlo más tarde o póngase en contacto haciendo clic <a href='https://www.lineaspase.com/contacto.php'>aquí</a>.";
                        }

                        $nombre = "";
                        $primerApellido = "";
                        $segundoApellido = "";
                        $dni = "";
                        $fechaNacimiento = "";
                        $telefono = "";
                        $email = "";
                        $nombreUsuario = "";
                        $contrasena = "";
                        $repetirContrasena = "";
                        $aceptarTerminos = "";
                    }
                }
            ?>



            <form method="POST" action="<?php echo limpiarCaracteres($_SERVER["PHP_SELF"]); ?>">
                <label for="nombre">Nombre:</label>
                <input type="text" name="nombre" id="nombre" maxlength="25" value="<?php echo $nombre; ?>" placeholder="Escribe aquí tu Nombre.">
                <?php
                    if (!empty($faltaNombre)) {
                        echo '<span class="faltanCampos">' . $faltaNombre . '</span> <br>';
                    }
                ?>

                <label for="primerApellido">Primer Apellido:</label>
                <input type="text" name="primerApellido" id="primerApellido" maxlength="25" value="<?php echo $primerApellido; ?>" placeholder="Escribe aquí tu Primer Apellido.">
                <?php
                    if (!empty($faltaPrimerApellido)) {
                        echo '<span class="faltanCampos">' . $faltaPrimerApellido . '</span> <br>';
                    }
                ?>

                <label for="segundoApellido">Segundo Apellido:</label>
                <input type="text" name="segundoApellido" id="segundoApellido" maxlength="25" value="<?php echo $segundoApellido; ?>" placeholder="Escribe aquí tu Segundo Apellido.">
                <?php
                    if (!empty($faltaSegundoApellido)) {
                        echo '<span class="faltanCampos">' . $faltaSegundoApellido . '</span> <br>';
                    }
                ?>

                <label for="dni">DNI:</label>
                <input type="text" name="dni" id="dni" maxlength="9" value="<?php echo $dni; ?>" placeholder="Escribe aquí tu DNI.">
                <?php
                    if (!empty($faltaDni)) {
                        echo '<span class="faltanCampos">' . $faltaDni . '</span> <br>';
                    }
                ?>

                <label for="fechaNacimiento">Fecha de Nacimiento:</label>
                <input type="date" name="fechaNacimiento" id="fechaNacimiento" value="<?php echo $fechaNacimiento; ?>"> <br>
                <?php
                    if (!empty($faltaFechaNacimiento)) {
                        echo '<span class="faltanCampos">' . $faltaFechaNacimiento . '</span> <br>';
                        echo '<style>form input[type="date"]{margin-top: 15px;}</style>';
                    }
                ?>

                <label for="telefono">Teléfono:</label>
                <input type="tel" name="telefono" id="numeroTelefono" maxlength="9" value="<?php echo $telefono; ?>" placeholder="Escribe aquí tu Número de Teléfono." onkeypress="return soloNumeros(event)"> <br>
                <?php
                    if (!empty($faltaTelefono)) {
                        echo '<span class="faltanCampos">' . $faltaTelefono . '</span> <br>';
                    }
                ?>

                <label for="email">Correo Electrónico:</label>
                <input type="email" name="email" id="email" maxlength="50" value="<?php echo $email; ?>" placeholder="Escribe aquí tu Correo Electrónico."> <br>
                <?php
                    if (!empty($faltaEmail)) {
                        echo '<span class="faltanCampos">' . $faltaEmail . '</span> <br>';
                    }
                ?>

                <label for="nombreUsuario">Nombre de Usuario</label>
                <input type="text" name="nombreUsuario" id="nombreUsuario" maxlength="20" value="<?php echo $nombreUsuario; ?>" placeholder="Escribe aquí tu Nombre de Usuario."> <br>
                <?php
                    if (!empty($faltaNombreUsuario)) {
                        echo '<span class="faltanCampos">' . $faltaNombreUsuario . '</span> <br>';
                    }
                ?>

                <label for="contrasena">Contraseña:</label>
                <input type="password" name="contrasena" id="contrasena" placeholder="Escribe aquí tu Contraseña."> <br>
                <?php
                    if (!empty($faltaContrasena)) {
                        echo '<span class="faltanCampos">' . $faltaContrasena . '</span> <br>';
                    }
                ?>

                <label for="repetirContrasena">Repite la Contraseña:</label>
                <input type="password" name="repetirContrasena" id="repetirContrasena" placeholder="Vuelve a escribir la Contraseña anterior."> <br>
                <?php
                    if (!empty($faltaRepetirContrasena)) {
                        echo '<span class="faltanCampos">' . $faltaRepetirContrasena . '</span> <br>';
                    }
                ?>

                <input type="checkbox" name="aceptarTerminos" id="aceptarTerminos" <?php if ($aceptarTerminos) echo 'checked'; ?> />He leído y estoy de acuerdo con la <a href="https://www.lineaspase.com/textosLegales.html#aceptoTerminos">Política de Privacidad<a>.</span> <span id="faltaTerminos" class="faltanCampos"></span> <br>
                <?php
                    if (!empty($faltaAceptarTerminos)) {
                        echo '<span class="faltanCampos">' . $faltaAceptarTerminos . '</span> <br>';
                    }
                ?>

                <input type="submit" value="Registrarme"> <br>
                <?php
                    if (!empty($mensajeRegistrado)) {
                        echo '<span class="registrado">' . $mensajeRegistrado .'</span>';
                    }

                    if (!empty($mensajeNoRegistrado)) {
                        echo '<span class="noRegistrado">' . $mensajeNoRegistrado .'</span>';
                    }
                ?>
        </div>
    </main>

    <div id="cookie-message" class="cookie-notification">
        <p>Este sitio web utiliza cookies que ayudan al funcionamiento del sitio web y para rastrear cómo interactúa con él para que podamos brindarle una experiencia de usuario mejorada y personalizada.</p>
        <button id="accept-cookies-btn">Aceptar</button>

        <script src="js/aceptarCookies.js"></script>
    </div>

    <footer>
        <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
    </footer>
</body>

</html>

<?php
    mysqli_close($enlace);
?>