<?php include "conexionBD.php"; ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Rutas y Horarios</title>

    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/rutasHorarios.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />

    <script src="js/cajasDesplegables.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/rutasHorarios.php" class="paginaActiva">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/textosLegales.html">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/nosotros.html">NOSOTROS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/iniciarSesion.php">Iniciar sesión</a>
                </li>
            </ul>
        </nav>
    </header>
        <main>
            <div class="contenidoPrincipal">
                <h1>RUTAS Y HORARIOS</h1>

                <?php /* LINEA L-1: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-1'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/registrarse.php' class='botonesComprar' title='Debe iniciar sesión'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-2: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-2'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/registrarse.php' class='botonesComprar' title='Debe iniciar sesión'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-3: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-3'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/registrarse.php' class='botonesComprar' title='Debe iniciar sesión'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-4: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-4'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/registrarse.php' class='botonesComprar' title='Debe iniciar sesión'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-5: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-5'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/registrarse.php' class='botonesComprar' title='Debe iniciar sesión'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-6 */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-6'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/registrarse.php' class='botonesComprar' title='Debe iniciar sesión'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>
            </div>
        </main>

        <div id="cookie-message" class="cookie-notification">
        <p>Este sitio web utiliza cookies que ayudan al funcionamiento del sitio web y para rastrear cómo interactúa con él para que podamos brindarle una experiencia de usuario mejorada y personalizada.</p>
        <button id="accept-cookies-btn">Aceptar</button>

        <script src="js/aceptarCookies.js"></script>
    </div>

        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
</body>
</html>

<?php
    mysqli_close($enlace);
?>