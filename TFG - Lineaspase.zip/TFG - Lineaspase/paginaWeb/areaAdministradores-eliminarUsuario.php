<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
    
    include "conexionBD.php";

    function limpiarCaracteres($datos) {
        $datos = trim($datos);
        $datos = stripslashes($datos);
        $datos = htmlspecialchars($datos);
        return $datos;
    }

    if (isset($_GET['dniUsuarioURL'])) {
        $dniUsuarioURL = limpiarCaracteres($_GET['dniUsuarioURL']);
    }

    $consultaEliminarUsuario = "DELETE FROM clientes WHERE clientes.nif = '$dniUsuarioURL'";
    $resultadoConsultaEliminarUsuario = mysqli_query($enlace, $consultaEliminarUsuario);

    if ($resultadoConsultaEliminarUsuario) {
        echo "<script>window.location='https://www.lineaspase.com/areaAdministradores-usuarios.php'</script>";
    }
?>