<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Textos Legales</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/textosLegales.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php">USUARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-flota.php">FLOTA</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php" class="paginaActiva">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>
        <main>
            <div class="contenidoPrincipal">
                <h1>TEXTOS LEGALES</h1>

                <h2>AVISO LEGAL</h2>

                <h3>LSSI</h3>
                <p>Para dar cumplimiento con el deber de la información recogido en el artículo 10 de la Ley 34/2002 del 11 de julio de Servicios de la Sociedad de la Información y de Comercio Electrónico, a continuación se reflejan los siguientes datos de información general del sitio Web www.lineaspase.com</p>
                
                <h3>Titular del Sitio Web de lineaspase</h3>
                <p>LINEASPASE SL</p>
                <p>CIF: B12226978</p>
                <p>Inscrita en el Registro Mercantil de Sevilla con fecha 05/04/2023, Tomo: 1548, Folio: 26, Hoja: SE-12.359</p>
                <p>Domicilio social: C/Arroyo, 80 CP 41008 Sevilla</p>
                <p>Teléfono: 954563320</p>
                <p>E-mail: linepase@lineaspase.com</p>

                <h3>Usuario</h3>
                <p>El acceso y/o uso de este sitio Web atribuye la condición de usuario, y acepta, desde dicho acceso y/o uso, las condiciones generales de uso que se describen en este apartado.</p>

                <h3>Utilización del Sitio Web</h3>
                <p>El sitio Web es ofrecido con fines informativos de carácter general sobre las actividades desarrolladas por LINEASPASE y los servicios prestados por la misma. LINEASPASE podrá dejar de prestar los servicios ofrecidos en este sitio Web sin realizar ninguna comunicación con el usuario, sin que ello conlleve obligación legal alguna para con el mismo.</p>

                <h3>Vínculo a Terceros</h3>
                <p>En el caso de vínculos a sitios de terceros, el usuario pasará a estar regido por las Condiciones Generales/ Aviso Legal del nuevo sitio. LINEASPASE no será responsable ni tendrá obligación legal por el uso de tales sitios.</p>

                <h3>Normas de uso y comunicación a la empresa</h3>
                <p>Las presentes normas para comunicar sugerencias a la empresa se aceptan desde el momento en que el usuario se registra aportando sus datos y comparte cualquier comentario.
                    Los comentarios que envíe el usuario deben estar relacionados con el tema que se trata.
                    No está permitido el envío de ningún tipo de publicidad. El contenido del mensaje enviado en la web no es visible ni accesible para el resto de usuarios de la Web.
                    En el momento que el usuario envía el mensaje, autoriza expresamente a LINEASPASE al uso de ese texto a través de la Web www.lineaspase.com. Asimismo, renuncia a pedir cualquier tipo de responsabilidad y/ o contraprestación por el referido uso.
                    Los usuarios utilizarán en todo momento un lenguaje apropiado y respetuoso. Está prohibido el envío de insultos, las faltas de respeto y los comentarios que puedan atentar contra los derechos de las personas. Serán descartados todos los comentarios de contenido racista, xenófobo, pedófilo, sexista, agresivo o de cualquier otro tipo que pudieran vulnerar derechos o ser ofensivos.</p>

                <h3>Exclusión de garantías y responsabilidad</h3>
                <p>LINEASPASE no se hace responsable, en ningún caso, de los daños y perjuicios de cualquier naturaleza que pudieran ocasionar, a título enunciativo y no limitativo: errores u omisiones en los contenidos, falta de disponibilidad del portal o la transmisión de virus o programas maliciosos o lesivos en los contenidos, a pesar de haber adoptado todas las medidas tecnológicas necesarias para evitarlo. Asimismo, aunque se intenta mantener la información actualizada, LINEASPASE no puede garantizar la exactitud de la información que ofrece en este sitio Web, que puede estar incompleta o contener errores.
                    Derechos de Autor (Propiedad intelectual e industrial)
                    Todos los textos e imágenes contenidos en el sitio Web de LINEASPASE poseen derechos de autor y no pueden ser reproducidos sin autorización por escrito de sus propietarios legales.
                    Privacidad

                <h3>Privacidad</h3>
                <p>La información que los usuarios proporcionen a LINEASPASE a través de los formularios de este sitio Web o mediante la remisión de correos electrónicos a las direcciones que aparecen en la página se utilizará para responder a la consulta realizada, gestionar la solicitud objeto del formulario remitido y facilitar a los interesados información a través de cualquier medio, incluido el correo electrónico y el sms, de sus servicios y actividades. Para más información acerca del tratamiento de datos en esta Web, consulte nuestra Política de Privacidad.</p>

                <h3>Legislación</h3>
                <p>Las presentes condiciones generales se regirán por la legislación española. Para la resolución de cualquier controversia que pudiera surgir en relación a las mismas, tanto LINEASPASE como los usuarios se someten a la jurisdicción de los Tribunales determinados legalmente.

                <h3>Modificación del Aviso Legal / Condiciones Generales</h3>
                <p>LINEASPASE podrá modificar el apartado Aviso legal / Condiciones Generales cuando lo considere pertinente. El usuario deberá revisar su contenido en cada visita, ya que los mismos pueden ser modificados sin previo aviso. Asimismo, comprende y acepta todas y cada una de las cláusulas contenidas en el presente documento. Es de la entera responsabilidad del usuario revisar los términos antes mencionados.</p>


                <h2 id="aceptoTerminos">POLÍTICA DE PRIVACIDAD</h2>

                <h3>1. INFORMACIÓN AL USUARIO</h3>
                <h4>¿Quién es el responsable del tratamiento de tus datos personales?</h4>
                <p> LINEASPASE SL es la RESPONSABLE del tratamiento de los datos personales del USUARIO y les informa de que estos datos serán tratados de conformidad con lo dispuesto en el Reglamento (UE) 2016/679, de 27 de abril (GDPR), y la Ley Orgánica 3/2018, de 5 de diciembre (LOPDGDD).</p>

                <h4>¿Para qué tratamos tus datos personales?</h4>
                <p>Para mantener una relación comercial con el usuario. Las operaciones previstas para realizar el tratamiento son:</p>
                <ul>
                    <li>Remisión de comunicaciones comerciales publicitarias por e-mail, fax, SMS, MMS, redes sociales o cualquier otro medio electrónico o físico, presente o futuro, que posibilite realizar comunicaciones comerciales. Estas comunicaciones serán realizadas por los RESPONSABLES y estarán relacionadas con sus productos y servicios, o de sus colaboradores o proveedores, con los que este haya alcanzado algún acuerdo de promoción. En este caso, los terceros nunca tendrán acceso a los datos personales.</li>
                    <li>Realizar estudios de mercado y análisis estadísticos.</li>
                    <li>Tramitar encargos, solicitudes, dar respuesta a las consultas o cualquier tipo de petición que sea realizada por el USUARIO a través de cualquiera de las formas de contacto que se ponen a su disposición en la página web de los RESPONSABLES.</li>
                    <li>Remitir el boletín informativo online, sobre novedades, ofertas y promociones en nuestra actividad.</li>
                </ul>

                <h4>¿Por qué motivo podemos tratar tus datos personales?</h4>
                <p>Porque el tratamiento está legitimado por el artículo 6 del GDPR de la siguiente forma:</p>
                <ul>
                    <li>Con el consentimiento del USUARIO: remisión de comunicaciones comerciales y del boletín informativo.</li>
                    <li>Por interés legítimo de los RESPONSABLES: realizar estudios de mercado, análisis estadísticos, etc. y tramitar encargos, solicitudes, etc. a petición del USUARIO.</li>
                </ul>

                <h4>¿Durante cuánto tiempo guardaremos tus datos personales?</h4>
                <p>Se conservarán durante no más tiempo del necesario para mantener el fin del tratamiento o existan prescripciones legales que dictaminen su custodia y cuando ya no sea necesario para ello, se suprimirán con medidas de seguridad adecuadas para garantizar la anonimización de los datos o la destrucción total de los mismos.</p>

                <h4>¿A quién facilitamos tus datos personales?</h4>
                <p>No está prevista ninguna comunicación de datos personales a terceros salvo, si fuese necesario para el desarrollo y ejecución de las finalidades del tratamiento, a nuestros proveedores de servicios relacionados con comunicaciones, con los cuales los RESPONSABLES tienen suscritos los contratos de confidencialidad y de encargado de tratamiento exigidos por la normativa vigente de privacidad.</p>

                <h4>¿Cuáles son tus derechos?</h4>
                <p>Los derechos que asisten al USUARIO son:</p>
                <ul>
                    <li>Derecho a retirar el consentimiento en cualquier momento.</li>
                    <li>Derecho de acceso, rectificación, portabilidad y supresión de sus datos, y de limitación u oposición a su tratamiento.</li>
                    <li>Derecho a presentar una reclamación ante la autoridad de control (www.aepd.es) si considera que el tratamiento no se ajusta a la normativa vigente.</li>
                </ul>
                <p>Datos de contacto para ejercer sus derechos:
                    LINEASPASE SL, CIF B12226978, con domicilio social en C/Arroyo, 80 CP 41008 Sevilla y dirección donde se realiza la actividad en C/Arroyo, 80 CP 41008 Sevilla.
                    Teléfono: 954 56 33 20
                    E-mail: linepase@lineaspase.com</p>

                <h3>2. CARÁCTER OBLIGATORIO O FACULTATIVO DE LA INFORMACIÓN FACILITADA POR EL USUARIO</h3>
                <p>Los USUARIOS, mediante la marcación de las casillas correspondientes y la entrada de datos en los campos, marcados con un asterisco (*) en el formulario de contacto o presentados en formularios de descarga, aceptan expresamente y de forma libre e inequívoca, que sus datos son necesarios para atender su petición, por parte del prestador, siendo voluntaria la inclusión de datos en los campos restantes. El USUARIO garantiza que los datos personales facilitados a los RESPONSABLES son veraces y se hace responsable de comunicar cualquier modificación de los mismos. El RESPONSABLE informa de que todos los datos solicitados a través del sitio web son obligatorios, ya que son necesarios para la prestación de un servicio óptimo al USUARIO. En caso de que no se faciliten todos los datos, no se garantiza que la información y servicios facilitados sean completamente ajustados a sus necesidades.</p>

                <h3>3. MEDIDAS DE SEGURIDAD</h3>
                <p>Que de conformidad con lo dispuesto en las normativas vigentes en protección de datos personales, los RESPONSABLES están cumpliendo con todas las disposiciones de las normativas GDPR y LOPDGDD para el tratamiento de los datos personales de su responsabilidad, y manifiestamente con los principios descritos en el artículo 5 del GDPR, por los cuales son tratados de manera lícita, leal y transparente en relación con el interesado y adecuados, pertinentes y limitados a lo necesario en relación con los fines para los que son tratados.

                    Los RESPONSABLES garantizan que han implementado políticas técnicas y organizativas apropiadas para aplicar las medidas de seguridad que establecen el GDPR y la LOPDGDD con el fin de proteger los derechos y libertades de los USUARIOS y les ha comunicado la información adecuada para que puedan ejercerlos.
                    
                    Para más información sobre las garantías de privacidad, puedes dirigirte a los RESPONSABLES a través de LINEASPASE SL, CIF B12226978, con domicilio social en C/Arroyo, 80 CP 41008 Sevilla y dirección donde se realiza la actividad en C/Arroyo, 80 CP 41008 Sevilla.
                    Teléfono: 954 56 33 20
                    E-mail: linepase@lineaspase.com</p>

                <h2>POLÍTICA DE COOKIES</h2>
                <h3>INFORMACIÓN SOBRE COOKIES​</h3>
                <p>Debido a la entrada en vigor de la referente modificación de la «Ley de Servicios de la Sociedad de la Información» (LSSICE) establecida por el Real Decreto 13/2012, es de obligación obtener el consentimiento expreso del usuario de todas las páginas web que usan cookies prescindibles, antes de que este navegue por ellas.</p>

                <h3>¿QUÉ SON LAS COOKIES?</h3>
                <p>Las cookies y otras tecnologías similares tales como local shared objects, flash cookies o píxeles, son herramientas empleadas por los servidores Web para almacenar y recuperar información acerca de sus visitantes, así como para ofrecer un correcto funcionamiento del sitio.
                    Mediante el uso de estos dispositivos se permite al servidor Web recordar algunos datos concernientes al usuario, como sus preferencias para la visualización de las páginas de ese servidor, nombre y contraseña, productos que más le interesan, etc.</p>
                
                <h3>COOKIES AFECTADAS POR LA NORMATIVA Y COOKIES EXCEPTUADAS</h3>
                <p>Según la directiva de la UE, las cookies que requieren el consentimiento informado por parte del usuario son las cookies de analítica y las de publicidad y afiliación, quedando exceptuadas las de carácter técnico y las necesarias para el funcionamiento del sitio web o la prestación de servicios expresamente solicitados por el usuario.</p>

                <h3>¿QUÉ TIPOS DE COOKIES EXISTEN?​</h3>
                <h4>SEGÚN LA FINALIDAD</h4>
                <ul>
                    <li>Cookies técnicas y funcionales: son aquellas que permiten al usuario la navegación a través de una página web, plataforma o aplicación y la utilización de las diferentes opciones o servicios que en ella existan como, p. ej., controlar el tráfico y la comunicación de datos, identificar la sesión, acceder a partes de acceso restringido, recordar los elementos de un pedido, realizar el proceso de compra de un pedido, realizar la inscripción o participación en un evento, utilizar elementos de seguridad durante la navegación, almacenar contenidos para la difusión de vídeos o sonido o compartir contenidos a través de redes sociales. Incluyen las cookies de personalización, que son las que permiten al usuario acceder al servicio con algunas características de carácter general predefinidas en función de una serie de criterios en el terminal del usuario como, p. ej., el idioma, el tipo de navegador, la configuración regional desde donde accede al servicio, etc.</li>
                    <li>Cookies analíticas: son aquellas que permiten al responsable de las mismas el seguimiento y análisis del comportamiento de los usuarios de los sitios web a los que están vinculadas. La información recogida mediante este tipo de cookies se utiliza en la medición de la actividad de los sitios web, aplicación o plataforma y para la elaboración de perfiles de navegación de los usuarios de dichos sitios, aplicaciones y plataformas, con el fin de introducir mejoras en función del análisis de los datos de uso que hacen los usuarios del servicio.</li>
                    <li>Cookies publicitarias: son aquellas que permiten la gestión, de la forma más eficaz posible, de los espacios publicitarios que, en su caso, el editor haya incluido en una página web, aplicación o plataforma desde la que presta el servicio solicitado en base a criterios como el contenido editado o la frecuencia en la que se muestran los anuncios.</li>
                    <li>Cookies de publicidad comportamental: recogen información sobre las preferencias y elecciones personales del usuario (retargeting) para permitir la gestión, de la forma más eficaz posible, de los espacios publicitarios que, en su caso, el editor haya incluido en una página web, aplicación o plataforma desde la que presta el servicio solicitado</li>
                    <li>Cookies sociales: son establecidas por las plataformas de redes sociales en los servicios para permitirle compartir contenido con sus amigos y redes. Las plataformas de medios sociales tienen la capacidad de rastrear su actividad en línea fuera de los Servicios. Esto puede afectar al contenido y los mensajes que ve en otros servicios que visita.</li>
                    <li>Cookies de afiliados: permiten hacer un seguimiento de las visitas procedentes de otras webs, con las que el sitio web establece un contrato de afiliación (empresas de afiliación).</li>
                    <li>Cookies de seguridad: almacenan información cifrada para evitar que los datos guardados en ellas sean vulnerables a ataques maliciosos de terceros. Se usan solo en conexiones HTTPS.</li>
                </ul>

                <h4>SEGÚN LA PROPIEDAD</h4>
                <ul>
                    <li>Cookies propias: son aquellas que se envían al equipo terminal del usuario desde un equipo o dominio gestionado por el propio editor y desde el que se presta el servicio solicitado por el usuario.</li>
                    <li>Cookies de terceros: son aquellas que se envían al equipo terminal del usuario desde un equipo o dominio que no es gestionado por el editor, sino por otra entidad que trata los datos obtenidos través de las cookies.</li>
                <p>SEGÚN EL PLAZO DE CONSERVACIÓN</p>
                    <li>Cookies de sesión: son un tipo de cookies diseñadas para recabar y almacenar datos mientras el usuario accede a una página web.</li>
                    <li>Cookies persistentes: son un tipo de cookies en el que los datos siguen almacenados en el terminal y pueden ser accedidos y tratados durante un período definido por el responsable de la cookie , y que puede ir de unos minutos a varios años.</li>
                </ul>

                <h4>TRATAMIENTO DE DATOS PERSONALES</h4>
                <p>
                    Lineaspase es responsable del tratamiento de los datos personales del Interesado y le informa de que estos datos serán tratados de conformidad con lo dispuesto en el Reglamento (UE) 2016/679, de 27 de abril de 2016 (GDPR), por lo que se le facilita la siguiente información del tratamiento:
                    <br>Fines del tratamiento: según se especifica en el apartado de cookies que se utilizan en este sitio web.

                    <br>Legitimación del tratamiento: por interés legítimo del responsable: cookies técnicas y por consentimiento del interesado: cookies analíticas comportamentales y publicitarias.
                    Criterios de conservación de los datos: según se especifica en el apartado de cookies utilizadas en la web.
                    Comunicación de los datos: no se comunicarán los datos a terceros, excepto en cookies propiedad de terceros o por obligación legal.
                    <br>Derechos que asisten al Interesado:
                    <li>Derecho a retirar el consentimiento en cualquier momento.</li>
                    <li>Derecho de acceso, rectificación, portabilidad y supresión de sus datos y a la limitación u oposición a su tratamiento.</li>
                    <li>Derecho a presentar una reclamación ante la Autoridad de control (www.aepd.es) si considera que el tratamiento no se ajusta a la normativa vigente.</li>
                </p>
                <p>
                Datos de contacto para ejercer sus derechos:
                    <br>Lineaspase, CIF B12226978, con domicilio social en C/Arroyo, 80 CP 41008 Sevilla y dirección donde se realiza la actividad en C/Arroyo, 80 CP 41008 Sevilla.
                    <br>Teléfono: 954 56 33 20
                    <br>E-mail: linepase@lineaspase.com
                </p>

                <h4>COOKIES QUE SE UTILIZAN EN ESTE SITIO WEB​</h4>
                <table>
                    <tr>
                        <th>Nombre</th>
                        <th>Propósito</th>
                        <th>Caducidad</th>
                    </tr>
                    <tr>
                        <td>Rol</td>
                        <td>Para identificar el tipo de usuario y brindarle su experiencia correspondiente</td>
                        <td>24 horas</td>
                    </tr>
                    <tr>
                        <td>CookieAccepted</td>
                        <td>Utilizada para detectar si el visitante ha aceptado la categoría de marketing en el banner de cookies. Esta cookie es necesaria para que la web cumpla con el RGPD.</td>
                        <td>1 año</td>
                    </tr>
                </table> 
                    <br>

                    <h3>REVOCACIÓN DEL CONSENTIMIENTO PARA INSTALAR COOKIES</h3>
                    <h4>CÓMO ELIMINAR LAS COOKIES DEL NAVEGADOR</h4>
                    <p>Usted puede permitir, bloquear o eliminar las cookies instaladas en su equipo mediante la configuración de las opciones del navegador instalado en su ordenador:</p>
                    <ul>
                        <li>Chrome, desde <a href="http://support.google.com/chrome/bin/answer.py?hl=es&answer=95647" target="_blank"> http://support.google.com/chrome/bin/answer.py?hl=es&answer=95647</a></li>
                        <li>Safari, desde <a href="http://support.apple.com/kb/ph5042" target="_blank"> http://support.apple.com/kb/ph5042</a></li>
                        <li>Explorer, desde <a href="http://windows.microsoft.com/es-es/windows7/how-to-manage-cookies-in-internet-explorer-9" target="_blank"> http://windows.microsoft.com/es-es/windows7/how-to-manage-cookies-in-internet-explorer-9</a></li>
                        <li>Firefox, desde <a href="http://support.mozilla.org/es/kb/habilitar-y-deshabilitar-cookies-que-los-sitios-we" target="_blank"> http://support.mozilla.org/es/kb/habilitar-y-deshabilitar-cookies-que-los-sitios-we</a></li>
                    </ul>
            </div>
        </main>
        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
</body>
</html>