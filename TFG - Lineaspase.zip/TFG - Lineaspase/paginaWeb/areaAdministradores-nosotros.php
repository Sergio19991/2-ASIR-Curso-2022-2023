<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Nosotros</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/nosotros.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php">USUARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-flota.php">FLOTA</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php" class="paginaActiva">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>
        <main>
        <div class="contenidoPrincipal">

            <h1>NOSOTROS</h1>

            <p class="parrafoInicial">Si has llegado hasta aquí es porque antes has tenido que subir empinadas cuestas, sortear profundos baches, esquivar grandes obstáculos. Lineaspase ha tenido que hacer lo mismo durante toda su trayectoria y, por eso, a partir de nuestro cruce contigo queremos brindarte la mejor experiencia durante el resto del camino, mejorando y cuidando de los que más nos importa, poniéndote fácil y comodo el viaje hacia tu destino favorito.</p>

            <h2>Historia</h2>
            <div class="cajas">
                <img src="img/nosotrosHistoria.jpg" alt="Autobuses Históricos" class="imagenesIzquierda">
                <div class="parrafos">
                    <p>Somos Lineaspase, una empresa que ofrece servicios de transporte terrestre fundada en 2023 por los estudiantes del IES Antonio Machado: Pablo Domínguez y Sergio Bejarano.</p>
                    <p>Nuestra historia comienza en 2021. Pablo y Sergio se conocieron estudiando en el IES Antonio Machado, entonces en marzo del 2023, con la idea de iniciar su trabajo final de grado, decidieron hacerlo sobre el sector de los transportes de viajeros por carretera. Desde entonces, han ido adquiriendo experiencia y conocimientos en el sector del transporte por carretera, hasta que se creó la empresa Lineaspase.</p>
                </div>
            </div>


            <h2>Objetivos</h2>
            <div class="cajas">
                <div class="parrafos">
                    <p>En un mundo en constante movimiento, donde la conectividad y la movilidad son aspectos esenciales de nuestra vida cotidiana, la industria del transporte juega un papel crucial. En particular, el transporte en autobús sigue siendo una opción popular para millones de personas en todo el mundo debido a su accesibilidad, asequibilidad y flexibilidad. En este contexto, surge la oportunidad de emprender en el sector de la movilidad en autobús, ofreciendo una solución conveniente para los viajeros.</p>
                </div>
                <img src="img/nosotrosObjetivos.jpg" alt="Objetivos" class="imagenesDerecha">
            </div>

            <h2>Servicios</h2>
            <div class="cajas">
                <img src="img/nostrosServicios.jpeg" alt="Fila de Autobuses" class="imagenesIzquierda">
                <div class="parrafos">
                    <p>En la actualidad, ofrecemos una amplia gama de servicios a nuestros clientes y contamos con una flota de autobuses que cumplen con todas las normativas nacionales y de la UE en materia de transporte y seguridad, y con un gran equipo humano y técnico para mantener el excelente servicio que nuestros clientes merecen.</p>
                    <p>Hoy en día, Lineaspase es una de las empresas de autobuses que está arrancando en el sector y se ha convertido en sinónimo de calidad y seguridad en el transporte de pasajeros.</p>
                </div>
            </div>

            <h2>Tripulación</h2>
            <div class="cajas">
                <div class="parrafos">
                    <p>Viaje con la tranquilidad que ofrece Lineaspase.</p>
                    <p>Somos una empresa que proporciona a los clientes un transporte seguro, cómodo y fiable para garantizar que nuestros clientes disfruten del mejor servicio. Nuestro equipo de conductores expertos tienen años de experiencia y ya forman parte de nosotros</p>
                </div>
                    <img src="img/nostrosTripulación.png" alt="Tripulación de Autobuses" class="imagenesDerecha">
        </div>
    </div>
    </main>
        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
</body>
</html>