<?php include "conexionBD.php"; ?>

<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
        $dni = $_SESSION["dni"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Imprimir Ticket</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/ticket.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/imprimirTicket.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php">USUARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-flota.php">FLOTA</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>

    <body>
        <main>

            <div class="contenidoPrincipal">

                <h1 class="titulo">IMPRIMIR TICKET</h1>

                <?php
                    function limpiarCaracteres($datos) {
                        $datos = trim($datos);
                        $datos = stripslashes($datos);
                        $datos = htmlspecialchars($datos);
                        return $datos;
                    }

                    if (isset($_GET['numeroReferencia'])) {
                        $numeroReferencia = limpiarCaracteres($_GET['numeroReferencia']);
                    }                    

                    $consultaTicket = "SELECT tickets.linea AS 'nombreLinea', tickets.localidad_origen AS 'nombreLocalidadOrigen', tickets.ciudad_origen AS 'nombreCiudadOrigen', tickets.localidad_destino AS 'nombreLocalidadDestino', tickets.ciudad_destino AS 'nombreCiudadDestino', tickets.fecha_salida_llegada AS 'fechaSalida', tickets.hora_salida AS 'horaSalida', tickets.fecha_salida_llegada AS 'fechaLlegada', tickets.hora_llegada AS 'horaLlegada', tickets.estacion_origen AS 'nombreEstacionOrigen', tickets.estacion_destino AS 'nombreEstacionDestino', tickets.cantidad AS 'cantidad', tickets.precio AS 'precio', tickets.fecha_compra AS 'fechaCompra', tickets.hora_compra AS 'horaCompra', clientes.nombre AS 'nombreCliente', clientes.primer_apellido AS 'primerApellidoCliente', clientes.segundo_apellido AS 'segundoApellidoCliente', clientes.nif AS 'dniCliente'
                                       FROM tickets
                                       JOIN clientes ON tickets.nif_clientes = clientes.nif
                                       WHERE nif LIKE '{$dni}' AND tickets.numero_referencia LIKE '{$numeroReferencia}'";
                    $resultadoConsultaTicket = mysqli_query($enlace, $consultaTicket);

                    if($resultadoConsultaTicket) {
                        $fila = mysqli_fetch_assoc($resultadoConsultaTicket);

                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $nombreLocalidadOrigen = mysqli_real_escape_string($enlace, $fila['nombreLocalidadOrigen']);
                        $nombreCiudadOrigen = mysqli_real_escape_string($enlace, $fila['nombreCiudadOrigen']);
                        $nombreLocalidadDestino = mysqli_real_escape_string($enlace, $fila['nombreLocalidadDestino']);
                        $nombreCiudadDestino = mysqli_real_escape_string($enlace, $fila['nombreCiudadDestino']);
                        $fechaSalida = mysqli_real_escape_string($enlace, $fila['fechaSalida']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $fechaLlegada = mysqli_real_escape_string($enlace, $fila['fechaLlegada']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        $nombreEstacionOrigen = mysqli_real_escape_string($enlace, $fila['nombreEstacionOrigen']);
                        $nombreEstacionDestino = mysqli_real_escape_string($enlace, $fila['nombreEstacionDestino']);
                        $cantidad = mysqli_real_escape_string($enlace, $fila['cantidad']);
                        $precio = mysqli_real_escape_string($enlace, $fila['precio']);
                        $fechaCompra = mysqli_real_escape_string($enlace, $fila['fechaCompra']);
                        $horaCompra = mysqli_real_escape_string($enlace, $fila['horaCompra']);
                        $nombreCliente = mysqli_real_escape_string($enlace, $fila['nombreCliente']);
                        $primerApellidoCliente = mysqli_real_escape_string($enlace, $fila['primerApellidoCliente']);
                        $segundoApellidoCliente = mysqli_real_escape_string($enlace, $fila['segundoApellidoCliente']);
                        $dniCliente = mysqli_real_escape_string($enlace, $fila['dniCliente']);

                        $fechaSalidaObjeto = date_create_from_format('Y-m-d', $fechaSalida);
                        $fechaLlegadaObjeto = date_create_from_format('Y-m-d', $fechaLlegada);
                        $fechaCompraObjeto = date_create_from_format('Y-m-d', $fechaCompra);

                        $fechaSalidaObjetoFormateada = $fechaSalidaObjeto->format('d/m/Y');
                        $fechaLlegadaObjetoFormateada = $fechaLlegadaObjeto->format('d/m/Y');
                        $fechaCompraObjetoFormateada = $fechaCompraObjeto->format('d/m/Y');
                        
                        echo '<p class="informacionTicket">A continuación puede imprimir su Ticket y mostrárselo al Chofer. Gracias y que tenga un buen viaje.</p>';
                        echo '<div class="ticketCompra" id="ticketCompra">';
                        echo '  <ul>';
                        echo '      <li>Línea ' . $nombreLinea . ' : ' . $nombreLocalidadOrigen . ' (' . $nombreCiudadOrigen . ') - ' . $nombreLocalidadDestino . ' (' . $nombreCiudadDestino .')</li>';
                        echo '      <li>Fecha y Hora de Salida: ' . $fechaSalidaObjetoFormateada . ' - ' . $horaSalida . '. (Estación: "' . $nombreEstacionOrigen . '").</li>';
                        echo '      <li>Fecha y Hora de Llegada: ' . $fechaLlegadaObjetoFormateada . ' - ' . $horaLlegada . '. (Estación: "' . $nombreEstacionDestino . '").</li>';
                        echo '      <li>Cantidad de Billetes: ' . $cantidad . '. (Por ' . number_format($precio, 2, ',', '.') . '€ cada uno).</li>';
                        echo '      <li>Total: ' . number_format(($precio * $cantidad), 2, ',', '.') . '€. (IVA incluido).</li>';
                        echo '  </ul>';
                        echo '<p class="autorCompra">Compra realizada el ' . $fechaCompraObjetoFormateada . ' a las ' . $horaCompra . ' por ' . $nombreCliente . ' ' . $primerApellidoCliente . ' ' . $segundoApellidoCliente . ' (' . $dniCliente . ').</p>';
                        echo '</div>';
                        echo '<div class="botonImprimir">';
                        echo '  <button onclick="imprimirTicket()">IMPRIMIR</button>';
                        echo '  <a href="https://www.lineaspase.com/areaAdministradores-misCompras.php" class="botonVolver" title="Volver a Rutas y Horarios">Volver</a>';
                        echo '</div>';
                    } else {
                        echo "hola";
                    }
                ?>
            </div>

        </main>

        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
        
    </body>

</html>

<?php
    mysqli_close($enlace);
?>