<?php include "conexionBD.php"; ?>

<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Usuarios</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/usuarios.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/alertaRol.js"></script>
    <script src="js/soloNumeros.js"></script>
    <script src="js/confirmacionEliminar.js"></script>
    <script src="js/mostrarOcultarCajaDeslizante.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php" class="paginaActiva">USUARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-flota.php">FLOTA</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>
        <main>
            <div class="contenidoPrincipal">
                <h1>USUARIOS</h1>

                <?php
                        $consultarUsuarios = "SELECT nif AS 'dniUsuario', nombre AS 'nombre', primer_apellido AS 'primerApellido', segundo_apellido AS 'segundoApellido', fecha_nacimiento AS 'fechaNacimiento', telefono AS 'telefono', email AS 'email', nombre_usuario AS 'nombreUsuario', rol AS 'rol'
                                              FROM clientes
                                              ORDER BY clientes.nombre ASC";
                        $resultadoConsultarUsuarios = mysqli_query($enlace, $consultarUsuarios);

                        if($resultadoConsultarUsuarios) {
                            $fila = mysqli_fetch_assoc($resultadoConsultarUsuarios);

                            $dniUsuario = mysqli_real_escape_string($enlace, $fila['dniUsuario']);
                            $nombre = mysqli_real_escape_string($enlace, $fila['nombre']);
                            $primerApellido = mysqli_real_escape_string($enlace, $fila['primerApellido']);
                            $segundoApellido = mysqli_real_escape_string($enlace, $fila['segundoApellido']);
                            $fechaNacimiento = mysqli_real_escape_string($enlace, $fila['fechaNacimiento']);
                            $telefono = mysqli_real_escape_string($enlace, $fila['telefono']);
                            $email = mysqli_real_escape_string($enlace, $fila['email']);
                            $nombreUsuario = mysqli_real_escape_string($enlace, $fila['nombreUsuario']);
                            $rol = mysqli_real_escape_string($enlace, $fila['rol']);

                            echo "<table class='table table-striped table-hover'>";
                            echo "<tr>";
                            echo "  <th>NIF:</th>";
                            echo "  <th>Nombre:</th>";
                            echo "  <th>Primer Apellido:</th>";
                            echo "  <th>Segundo Apellido:</th>";
                            echo "  <th>Fecha de Nacimiento:</th>";
                            echo "  <th>Teléfono:</th>";
                            echo "  <th>Correo Electrónico:</th>";
                            echo "  <th>Nombre de Usuario</th>";
                            echo "  <th>Rol:</th>";
                            echo "  <th>Acciones:</th>";
                            echo "</tr>";

                            echo "<tr>";
                            echo '  <td>' . $dniUsuario . '</td>';
                            echo '  <td>' . $nombre . '</td>';
                            echo '  <td>' . $primerApellido . '</td>';
                            echo '  <td>' . $segundoApellido . '</td>';
                            echo '  <td>' . $fechaNacimiento . '</td>';
                            echo '  <td>' . $telefono . '</td>';
                            echo '  <td>' . $email . '</td>';
                            echo '  <td>' . $nombreUsuario . '</td>';
                            echo '  <td>' . $rol . '</td>';
                            echo "  <td class='iconoAcciones'><a href='https://www.lineaspase.com/areaAdministradores-modificarUsuario.php?dniUsuarioURL={$dniUsuario}'> <img src='img/iconoModificar.png' class='iconoModificar' title='Modificar'> </a>  <a href='https://www.lineaspase.com/areaAdministradores-eliminarUsuario.php?dniUsuarioURL={$dniUsuario}' onclick=\"return confirm('¿Estás seguro de que deseas eliminar este usuario?')\"> <img src='img/iconoEliminar.png' class='iconoEliminar' title='Eliminar'> </a> </td>";
                            echo "</tr>";

                            while ($fila = mysqli_fetch_assoc($resultadoConsultarUsuarios)) {
                                $dniUsuario = mysqli_real_escape_string($enlace, $fila['dniUsuario']);
                                $nombre = mysqli_real_escape_string($enlace, $fila['nombre']);
                                $primerApellido = mysqli_real_escape_string($enlace, $fila['primerApellido']);
                                $segundoApellido = mysqli_real_escape_string($enlace, $fila['segundoApellido']);
                                $fechaNacimiento = mysqli_real_escape_string($enlace, $fila['fechaNacimiento']);
                                $telefono = mysqli_real_escape_string($enlace, $fila['telefono']);
                                $email = mysqli_real_escape_string($enlace, $fila['email']);
                                $nombreUsuario = mysqli_real_escape_string($enlace, $fila['nombreUsuario']);
                                $rol = mysqli_real_escape_string($enlace, $fila['rol']);

                                echo "<tr>";
                                echo '  <td>' . $dniUsuario . '</td>';
                                echo '  <td>' . $nombre . '</td>';
                                echo '  <td>' . $primerApellido . '</td>';
                                echo '  <td>' . $segundoApellido . '</td>';
                                echo '  <td>' . $fechaNacimiento . '</td>';
                                echo '  <td>' . $telefono . '</td>';
                                echo '  <td>' . $email . '</td>';
                                echo '  <td>' . $nombreUsuario . '</td>';
                                echo '  <td>' . $rol . '</td>';
                                echo "  <td class='iconoAcciones'><a href='https://www.lineaspase.com/areaAdministradores-modificarUsuario.php?dniUsuarioURL={$dniUsuario}'> <img src='img/iconoModificar.png' class='iconoModificar' title='Modificar'> </a>  <a href='https://www.lineaspase.com/areaAdministradores-eliminarUsuario.php?dniUsuarioURL={$dniUsuario}' onclick=\"return confirm('¿Estás seguro de que deseas eliminar este usuario?')\"> <img src='img/iconoEliminar.png' class='iconoEliminar' title='Eliminar'> </a> </td>";
                                echo "</tr>";
                            }

                            echo "</table>";
                        } else {
                            echo "<p class='mensajeError'>Lo sentimos, en estos momentos no ha sido posible recupara los Datos. Por favor, vuelva a intentarlo más tarde o póngase en conctacto con el Administrador de la Base de Datos.</p>";
                        }
                ?>

                <a href="https://www.lineaspase.com/areaAdministradores-crearUsuario.php" class="botonCrearUsuario">+ Crear Usuario</a>
            </div>
        </main>

        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
    </body>
</html>

<?php
    mysqli_close($enlace);
?>