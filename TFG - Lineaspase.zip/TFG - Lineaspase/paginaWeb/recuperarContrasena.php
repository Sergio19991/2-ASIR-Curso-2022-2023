<?php require_once "conexionBD.php"; ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Recuperar Contraseña</title>

    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/recuperarContrasena.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/textosLegales.html">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/nosotros.html">NOSOTROS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/iniciarSesion.php" class="paginaActiva">Iniciar sesión</a>
                </li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="contenidoPrincipal">
            <h1>RECUPERAR CONTRASEÑA</h1>

            <?php
                function limpiarCaracteres($datos) {
                    $datos = trim($datos);
                    $datos = stripslashes($datos);
                    $datos = htmlspecialchars($datos);
                    return $datos;
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $email = limpiarCaracteres($_POST["email"]);
                    $dni = limpiarCaracteres($_POST["dni"]);

                    if (empty($email)) {
                        $faltaEmail = "*Debes introducir el Correo Electrónico.";
                    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $faltaEmail = "*El Correo Electrónico que has introducido no es válido.";
                    } elseif (strlen($email) > 50) {
                        $faltaEmail = "*El Correo Electrónico que has introducido no puede contener más de 50 Carácteres.";
                    }

                    if (empty($dni)) {
                        $faltaDni = "*Debes escribir tu DNI.";
                    } elseif (preg_match('/^[0-9]{8}[A-Z]$/', $dni)) {
                        $numero = substr($dni, 0, 8);
                        $letra = strtoupper(substr($dni, -1));
                        $letras_validas = 'TRWAGMYFPDXBNJZSQVHLCKE';
                        $letraCalculada = $letras_validas[$numero % 23];

                        if ($letraCalculada <> $letra) {
                            $faltaDni = "*El DNI que has introducido no es válido.";
                        }
                    } else {
                        $faltaDni = "*El DNI que has introducido no es válido.";
                    }

                    if ((empty($faltaDni)) && (empty($faltaEmail))) {
                        $consultarCoincidencia = "SELECT nif, email
                                                  FROM clientes
                                                  WHERE nif LIKE '{$dni}' AND email LIKE '{$email}'";
                        $resultadoConsultarCoincidencia = mysqli_query($enlace, $consultarCoincidencia);

                        if (mysqli_num_rows($resultadoConsultarCoincidencia) > 0) {
                            $token = rand(10000, 99999);

                            $destinatario = $email;
                            $encabezado = 'Recupera tu contraseña:';
                            $cuerpoMensaje = 'Hola, has solicitado restablecer tu Contraseña. Haz clic en el siguiente enlace para continuar:' . "\r\n" . 'https://www.lineaspase.com/restablecerContrasena.php?dni=' . $dni . '&token=' . $token . '';
                            $headers = 'From: lineaspase@lineaspase.com' . "\r\n" .
                                       'Reply-To: lineaspase@lineaspase.com' . "\r\n" .
                                       'X-Mailer: PHP/' . phpversion();
                        
                            mail($destinatario, $encabezado, $cuerpoMensaje, $headers);

                            $almacenarTokenBD = "INSERT INTO tokensContrasenas (nif, token) VALUES ('$dni ', '$token')";
                            $resultadoAlmacenarTokenBD = mysqli_query($enlace, $almacenarTokenBD);

                            $emailEnviado = "Se le ha enviado un Correo Eletrónico para recupear la Contraseña.";
                        } else {
                            $emailNoEnviado = "*La combinación de Correo Electrónico y DNI no son correctos.";
                        }
                    }
                }
            ?>

            <form method="POST" action="<?php echo limpiarCaracteres($_SERVER["PHP_SELF"]); ?>">
                <label for="email">Correo Electrónico:</label>
                <input type="email" name="email" id="email" placeholder="Escribe aquí tu Correo Electrónico.">
                <?php
                    if (!empty($faltaEmail)) {
                        echo '<span class="faltanCampos">' . $faltaEmail . '</span> <br>';
                    }
                ?>

                <label for="dni">DNI:</label>
                <input type="text" name="dni" id="dni" placeholder="Escribe aquí tu DNI.">
                <?php
                    if (!empty($faltaDni)) {
                        echo '<span class="faltanCampos">' . $faltaDni . '</span> <br>';
                    }
                ?>

                <input type="submit" value="Enviar">
                <a href="https://www.lineaspase.com/iniciarSesion.php" class="botonVolver">Cancelar y volver</a> <br>

                <?php echo "<span class='emailEnviado'>$emailEnviado</span>"; ?>
                <?php echo "<span class='emailNoEnviado'>$emailNoEnviado</span>"; ?>
            </form>
        </div>
    </main>

    <footer>
        <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
    </footer>
</body>

</html>

<?php
    mysqli_close($enlace);
?>