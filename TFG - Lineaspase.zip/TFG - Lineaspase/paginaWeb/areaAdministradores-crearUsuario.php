<?php include "conexionBD.php"; ?>

<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
        $email = $_SESSION["email"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Crear Usuario</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/crearUsuarios.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/alertaRol.js"></script>
    <script src="js/soloNumeros.js"></script>
</head>

<body>
    <header>
    <nav>
        <ul>
            <li class="inicio">
                <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
            </li>
            <li>
                <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php">USUARIOS</a>
            </li>
            <li>
                <a href="https://www.lineaspase.com/areaAdministradores-flota.php">FLOTA</a>
            </li>
            <li>
                <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
            </li>
            <li>
                <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
            </li>
            <li>
                <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php">TEXTOS LEGALES</a>
            </li>
            <li>
                <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php">NOSOTROS</a>
            </li>
            <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php
                        echo "Bienvenid@ $nombreUsuario";
                    ?>
                </a>
                <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
            </li>
        </ul>
        </nav>
    </header>
    <main>
        <div class="contenidoPrincipal">
            <h1>CREAR USUARIOS</h1>

            <?php
                error_reporting(E_ALL & ~E_NOTICE);

                $faltaNombre = "";
                $faltaPrimerApellido = "";
                $faltaSegundoApellido = "";
                $faltaDni = "";
                $faltaFechaNacimiento = "";
                $faltaTelefono = "";
                $faltaEmail = "";
                $faltaNombreUsuario = "";
                $faltaContrasena = "";
                $faltaRepetirContrasena = "";
                $faltaAceptarTerminos = "";
                $faltaRol = "";

                $nombre = "";
                $primerApellido = "";
                $segundoApellido = "";
                $dni = "";
                $fechaNacimiento = "";
                $telefono = "";
                $email = "";
                $nombreUsuario = "";
                $contrasena = "";
                $repetirContrasena = "";
                $rol = "";
                $aceptarTerminos = "";

                function limpiarCaracteres($datos) {
                    $datos = trim($datos);
                    $datos = stripslashes($datos);
                    $datos = htmlspecialchars($datos);
                    return $datos;
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $aceptarTerminos = "";
                    $nombre = limpiarCaracteres($_POST["nombre"]);
                    $primerApellido = limpiarCaracteres($_POST["primerApellido"]);
                    $segundoApellido = limpiarCaracteres($_POST["segundoApellido"]);
                    $dni = limpiarCaracteres($_POST["dni"]);
                    $fechaNacimiento = limpiarCaracteres($_POST["fechaNacimiento"]);
                    $telefono = limpiarCaracteres($_POST["telefono"]);
                    $email = limpiarCaracteres($_POST["email"]);
                    $nombreUsuario = limpiarCaracteres($_POST["nombreUsuario"]);
                    $contrasena = limpiarCaracteres($_POST["contrasena"]);
                    $repetirContrasena = limpiarCaracteres($_POST["repetirContrasena"]);
                    $rol = isset($_POST['rol']) ? $_POST['rol'] : '';
                    $aceptarTerminos = limpiarCaracteres($_POST["aceptarTerminos"]);

                    if (empty($nombre)) {
                        $faltaNombre = "*Debes escribir el Nombre.";
                    } elseif (strlen($nombre) > 25) {
                        $faltaNombreUsuario = "*El Nombre que has introducido no puede contener más de 25 Carácteres.";
                    }

                    if (empty($primerApellido)) {
                        $faltaPrimerApellido = "*Debes escribir el Primer Apellido.";
                    } elseif (strlen($primerApellido) > 25) {
                        $faltaPrimerApellido = "*El Primer Apellido que has introducido no puede contener más de 25 Carácteres.";
                    }

                    if (empty($segundoApellido)) {
                        $faltaSegundoApellido = "*Debes escribir el Segundo Apellido.";
                    } elseif (strlen($segundoApellido) > 25) {
                        $faltaSegundoApellido = "*El Segundo Apellido que has introducido no puede contener más de 25 Carácteres.";
                    }

                    $fechaActual = date("Y-m-d");
                    $edad = date_diff(date_create($fechaNacimiento), date_create($fechaActual))->y;

                    if (empty($fechaNacimiento)) {
                        $faltaFechaNacimiento = "*Debes introducir la Fecha de Nacimiento.";
                    } elseif ($edad < 18) {
                        $faltaFechaNacimiento = "*Debes tener al menos 18 años para poder registrarte.";
                    }

                    if (empty($dni)) {
                        $faltaDni = "*Debes escribir tu DNI.";
                    } elseif (preg_match('/^[0-9]{8}[A-Z]$/', $dni)) {
                        $numero = substr($dni, 0, 8);
                        $letra = strtoupper(substr($dni, -1));
                        $letras_validas = 'TRWAGMYFPDXBNJZSQVHLCKE';
                        $letraCalculada = $letras_validas[$numero % 23];

                        if ($letraCalculada <> $letra) {
                            $faltaDni = "*El DNI que has introducido no es válido.";
                        }
                    } else {
                        $faltaDni = "*El DNI que has introducido no es válido.";
                    }

                    if (empty($telefono)) {
                        $faltaTelefono = "*Debes escribir el Número de Teléfono.";
                    } elseif (!preg_match("/^[0-9]{9}$/", $telefono)) {
                        $faltaTelefono = "*El Número de Teléfono que has introducido no es válido.";
                    }

                    if (empty($email)) {
                        $faltaEmail = "*Debes introducir el Correo Electrónico.";
                    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $faltaEmail = "*El Correo Electrónico que has introducido no es válido.";
                    } elseif (strlen($email) > 50) {
                        $faltaEmail = "*El Correo Electrónico que has introducido no puede contener más de 50 Carácteres.";
                    }

                    if (empty($nombreUsuario)) {
                        $faltaNombreUsuario = "*Debes de introducir un Nombre de Usuario.";
                    } elseif (strpos($nombreUsuario, ' ') !== false) {
                        $faltaNombreUsuario = "*El Nombre de Usuario no puede contener espacios.";
                    } elseif (strlen($nombreUsuario) > 20) {
                        $faltaNombreUsuario = "*El Nombre de Usuario que has introducido no puede contenner más de 20 Carácteres.";
                    }

                    if (empty($contrasena)) {
                        $faltaContrasena = "*Debes introducir una Contraseña.";
                    } elseif ((strlen($contrasena) < 8) || (!preg_match('/[A-Z]/', $contrasena)) || (!preg_match('/[a-z]/', $contrasena)) || (!preg_match('/[0-9]/', $contrasena)) || (!preg_match('/[\W]/', $contrasena))) {
                        $faltaContrasena = "*La Contraseña que has introducido no cumple con los Requisitos Mínimos. (Debe tener, al menos, 8 Dígitos, una Letra Minúscula, una Letra Mayúscula, un Número y un Carácter Especial).";
                    }

                    if (empty($repetirContrasena)) {
                        $faltaRepetirContrasena = "*Debes introducir la misma Contraseña.";
                    } elseif (!($contrasena === $repetirContrasena)) {
                        $faltaRepetirContrasena = "*Las Contraseñas no coinciden.";
                        $faltaContrasena = "*Las Contraseñas no coinciden.";
                    }

                    if (empty($aceptarTerminos)) {
                        $faltaAceptarTerminos = "*Debes aceptar los Términos de la Política de Privacidad.";
                    }

                    $consultarUsuario = "SELECT nif AS 'dni', nombre_usuario AS 'nombreUsuario' FROM clientes";
                    $resultadoUsuario = mysqli_query($enlace, $consultarUsuario);

                    if (mysqli_num_rows($resultadoUsuario) > 0) {
                        while ($fila = mysqli_fetch_assoc($resultadoUsuario)) {
                            if (mysqli_real_escape_string($enlace, $fila["dni"]) == $dni) {
                                $faltaDni = "*Este DNI ya ha sido registrado anteriormente.";
                            }
                            if (mysqli_real_escape_string($enlace, $fila["nombreUsuario"]) == $nombreUsuario) {
                                $faltaNombreUsuario = "*Este Nombre de Usuario ya ha sido registrado anteriormente.";
                            }
                        }
                    }

                    if ((empty($faltaNombre)) && (empty($faltaPrimerApellido)) && (empty($faltaSegundoApellido)) && (empty($faltaDni)) && (empty($faltaFechaNacimiento)) && (empty($faltaTelefono)) && (empty($faltaEmail)) && (empty($faltaNombreUsuario)) && (empty($faltaContrasena)) && (empty($faltaRepetirContrasena)) && (empty($faltaAceptarTerminos))) {
                        $contrasenaCifrada = md5($contrasena);
                        $insertarUsuario = "INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ('{$dni}', '{$nombre}', '{$primerApellido}', '{$segundoApellido}', '{$fechaNacimiento}', '{$telefono}', '{$email}', '{$nombreUsuario}', '{$contrasenaCifrada}', '{$rol}')";
                        if (mysqli_query($enlace, $insertarUsuario)) {
                            $destinatario = $email;
                            $encabezado = '!BIENVENID@¡';
                            $cuerpoMensaje = 'Le comunicamos que se le ha creado una nueva cuenta en nuestra Página Web. Si tiene alguna duda póngase en contacto a través de nuestra Página Web' . "\r\n" . 'Recuerde cambiar su Contraseña antes de iniciar sesión a través de este Enlace https://www.lineaspase.com/recuperarContrasena.php';
                            $headers = 'From: lineaspase@lineaspase.com' . "\r\n" .
                                       'Reply-To: lineaspase@lineaspase.com' . "\r\n" .
                                       'X-Mailer: PHP/' . phpversion();
                            mail($destinatario, $encabezado, $cuerpoMensaje, $headers);
                            $mensajeRegistrado = "Usuario creado correctamente.";


                            $nombre = "";
                            $primerApellido = "";
                            $segundoApellido = "";
                            $dni = "";
                            $fechaNacimiento = "";
                            $telefono = "";
                            $email = "";
                            $nombreUsuario = "";
                            $contrasena = "";
                            $repetirContrasena = "";
                            $aceptarTerminos = "";
                        } else {
                            $mensajeNoRegistrado = "*No ha sido posbile registrar los Datos en estos momentos. Por favor, vuelva a intentarlo más tarde o póngase en contacto el Admininstrador de la Base de Datos.</a>.";
                            $contrasena = "";
                            $repetirContrasena = "";
                        }
                    }
                }
            ?>

            <form method="POST" action="<?php echo limpiarCaracteres($_SERVER["PHP_SELF"]); ?>">
                <label for="nombre">Nombre:</label>
                <input type="text" name="nombre" id="nombre" maxlength="25" value="<?php echo $nombre; ?>" placeholder="Escribe aquí el Nombre.">
                <?php
                    if (!empty($faltaNombre)) {
                        echo '<span class="faltanCampos">' . $faltaNombre . '</span> <br>';
                    }
                ?>

                <label for="primerApellido">Primer Apellido:</label>
                <input type="text" name="primerApellido" id="primerApellido" maxlength="25" value="<?php echo $primerApellido; ?>" placeholder="Escribe aquí el Primer Apellido.">
                <?php
                    if (!empty($faltaPrimerApellido)) {
                        echo '<span class="faltanCampos">' . $faltaPrimerApellido . '</span> <br>';
                    }
                ?>

                <label for="segundoApellido">Segundo Apellido:</label>
                <input type="text" name="segundoApellido" id="segundoApellido" maxlength="25" value="<?php echo $segundoApellido; ?>" placeholder="Escribe aquí el Segundo Apellido.">
                <?php
                    if (!empty($faltaSegundoApellido)) {
                        echo '<span class="faltanCampos">' . $faltaSegundoApellido . '</span> <br>';
                    }
                ?>

                <label for="dni">DNI:</label>
                <input type="text" name="dni" id="dni" maxlength="9" value="<?php echo $dni; ?>" placeholder="Escribe aquí el DNI.">
                <?php
                    if (!empty($faltaDni)) {
                        echo '<span class="faltanCampos">' . $faltaDni . '</span> <br>';
                    }
                ?>

                <label for="fechaNacimiento">Fecha de Nacimiento:</label>
                <input type="date" name="fechaNacimiento" id="fechaNacimiento" value="<?php echo $fechaNacimiento; ?>"> <br>
                <?php
                    if (!empty($faltaFechaNacimiento)) {
                        echo '<span class="faltanCampos">' . $faltaFechaNacimiento . '</span> <br>';
                        echo '<style>form input[type="date"]{margin-top: 15px;}</style>';
                    }
                ?>

                <label for="telefono">Teléfono:</label>
                <input type="tel" name="telefono" id="telefono" maxlength="9" value="<?php echo $telefono; ?>" placeholder="Escribe aquí el Número de Teléfono." onkeypress="return soloNumeros(event)"> <br>
                <?php
                    if (!empty($faltaTelefono)) {
                        echo '<span class="faltanCampos">' . $faltaTelefono . '</span> <br>';
                    }
                ?>

                <label for="email">Correo Electrónico:</label>
                <input type="email" name="email" id="email" maxlength="50" value="<?php echo $email; ?>" placeholder="Escribe aquí el Correo Electrónico."> <br>
                <?php
                    if (!empty($faltaEmail)) {
                        echo '<span class="faltanCampos">' . $faltaEmail . '</span> <br>';
                    }
                ?>

                <label for="nombreUsuario">Nombre de Usuario</label>
                <input type="text" name="nombreUsuario" id="nombreUsuario" maxlength="20" value="<?php echo $nombreUsuario; ?>" placeholder="Escribe aquí el Nombre de Usuario."> <br>
                <?php
                    if (!empty($faltaNombreUsuario)) {
                        echo '<span class="faltanCampos">' . $faltaNombreUsuario . '</span> <br>';
                    }
                ?>

                <label for="contrasena">Contraseña:</label>
                <input type="password" name="contrasena" id="contrasena" placeholder="Escribe aquí la Contraseña."> <br>
                <?php
                    if (!empty($faltaContrasena)) {
                        echo '<span class="faltanCampos">' . $faltaContrasena . '</span> <br>';
                    }
                ?>

                <label for="repetirContrasena">Repite la Contraseña:</label>
                <input type="password" name="repetirContrasena" id="repetirContrasena" placeholder="Vuelve a escribir la Contraseña anterior."> <br>
                <?php
                    if (!empty($faltaRepetirContrasena)) {
                        echo '<span class="faltanCampos">' . $faltaRepetirContrasena . '</span> <br>';
                    }
                ?>

                    <label for="rol" class="rol">Rol:</label>
                    <select name="rol" id="rol" onchange="mostrarAlertaRolModificadoCrearUsuarios()">
                        <option value="Cliente" <?php if ($rol === 'Cliente') { echo 'selected'; } ?>>Cliente</option>
                        <option value="Administrador" <?php if ($rol === 'Administrador') { echo 'selected'; } ?>>Administrador</option>
                    </select> <br>

                <input type="checkbox" name="aceptarTerminos" id="aceptarTerminos" <?php if ($aceptarTerminos) echo 'checked'; ?> />He leído y estoy de acuerdo con la <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php#aceptoTerminos">Política de Privacidad<a>.</span> <span id="faltaTerminos" class="faltanCampos"></span> <br>
                <?php
                    if (!empty($faltaAceptarTerminos)) {
                        echo '<span class="faltanCampos">' . $faltaAceptarTerminos . '</span> <br>';
                    }
                ?>

                <input type="submit" value="Registrar usuario">

                <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php" class="botonVolver">Cancelar y volver</a> <br>
                <?php
                    if (!empty($mensajeRegistrado)) {
                        echo '<span class="usuarioRegistrado">' . $mensajeRegistrado .'</span>';
                    }

                    if (!empty($mensajeNoRegistrado)) {
                        echo '<span class="usuarioNoRegistrado">' . $mensajeNoRegistrado .'</span>';
                    }
                ?>
        </div>
    </main>
    <footer>
        <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
    </footer>
</body>

</html>

<?php
    mysqli_close($enlace);
?>