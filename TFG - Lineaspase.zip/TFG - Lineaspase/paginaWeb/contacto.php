<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Contacto</title>

    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/contacto.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/contacto.php" class="paginaActiva">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/textosLegales.html">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/nosotros.html">NOSOTROS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/iniciarSesion.php">Iniciar sesión</a>
                </li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="contenidoPrincipal">
            <h1>CONTACTO</h1>
            <?php
                error_reporting(E_ALL & ~E_NOTICE);

                $nombre = "";
                $primerApellido = "";
                $segundoApellido = "";
                $email = "";
                $comentario = "";
                $aceptarTerminos = "";

                $faltaNombre = "";
                $faltaPrimerApellido = "";
                $faltaSegundoApellido = "";
                $faltaEmail = "";
                $faltaComentario = "";
                $faltaAceptarTerminos = "";

                $mensajeComentarioEnviado = "";

                function limpiarCaracteres($datos) {
                    $datos = trim($datos);
                    $datos = stripslashes($datos);
                    $datos = htmlspecialchars($datos);
                    return $datos;
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $nombre = limpiarCaracteres($_POST["nombre"]);
                    $primerApellido = limpiarCaracteres($_POST["primerApellido"]);
                    $segundoApellido = limpiarCaracteres($_POST["segundoApellido"]);
                    $email = limpiarCaracteres($_POST["email"]);
                    $comentario = limpiarCaracteres($_POST["comentario"]);
                    $aceptarTerminos = limpiarCaracteres($_POST["aceptarTerminos"]);

                    if (empty($nombre)) {
                        $faltaNombre = "*Debes de escribir tu Nombre.";
                    }
        
                    if (empty($primerApellido)) {
                        $faltaPrimerApellido = "*Debes de escribir tu Primer Apellido.";
                    }
        
                    if (empty($segundoApellido)) {
                        $faltaSegundoApellido = "*Debes de escribir tu Segundo Apellido.";
                    }
        
                    if (empty($email)) {
                        $faltaEmail = "*Debes de escribir tu Correo Electrónico.";
                    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            $faltaEmail = "*El Correo Electrónico que has introducido no es válido.";
                    }
        
                    if (empty($comentario)) {
                        $faltaComentario = "*Debes de escribir un Comentario.";
                    }
        
                    if (empty($aceptarTerminos)) {
                        $faltaAceptarTerminos = "*Debes aceptar los Términos de la Política de Privacidad.";
                    }
        
                    if ((empty($faltaNombre)) && (empty($faltaPrimerApellido)) && (empty($faltaSegundoApellido)) && (empty($faltaEmail)) && (empty($faltaComentario)) && (empty($faltaAceptarTerminos))) {
                        $nombre = "";
                        $primerApellido = "";
                        $segundoApellido = "";
                        $comentario = "";
                        $email = "";
                        $aceptarTerminos = "";
        
                        $mensajeComentarioEnviado = "Gracias por ponerte en contacto con nosotros.";
                    }
                }
            ?>

            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label for="nombre">Nombre:</label>
                <input type="text" name="nombre" value="<?php echo $nombre; ?>" placeholder="Escribe aquí tu nombre."><br>
                <?php
                    if (!empty($faltaNombre)) {
                        echo '<span class="faltanCampos">' . $faltaNombre . '</span> <br>';
                    }
                ?>

                <label for="primerApellido">Primer apellido:</label> 
                <input type="text" name="primerApellido" value="<?php echo $primerApellido; ?>" placeholder="Escribe aquí tu Primer Apellido."><br>
                <?php
                    if (!empty($faltaPrimerApellido)) {
                        echo '<span class="faltanCampos">' . $faltaPrimerApellido . '</span> <br>';
                    }
                ?>

                <label for="segundoApellido">Segundo apellido:</label> 
                <input type="text" name="segundoApellido" value="<?php echo $segundoApellido; ?>" placeholder="Escribe aquí tu Segundo Apellido."><br>
                <?php
                    if (!empty($faltaSegundoApellido)) {
                        echo '<span class="faltanCampos">' . $faltaSegundoApellido . '</span> <br>';
                    }
                ?>

                <label for="email">Email:</label> 
                <input type="email" name="email" value="<?php echo $email; ?>" placeholder="Escribe aquí tu Correo Eletrónico."><br>
                <?php
                    if (!empty($faltaEmail)) {
                        echo '<span class="faltanCampos">' . $faltaEmail . '</span> <br>';
                    }
                ?>

                <label for="comentario">Comentario:</label><br>
                <textarea name="comentario" cols="30" rows="10" placeholder="Escribe aquí tu comentario."><?php echo $comentario; ?></textarea><br>
                <?php
                    if (!empty($faltaComentario)) {
                        echo '<span class="faltanCampos">' . $faltaComentario . '</span> <br>';
                    }
                ?>

                <input type="checkbox" name="aceptarTerminos" <?php if ($aceptarTerminos) echo 'checked'; ?> /> <span class="terminos">He leído y estoy de acuerdo con la <a href="https://www.lineaspase.com/textosLegales.html#aceptoTerminos">Política de Privacidad<a>.</span><br>
                <?php
                    if (!empty($faltaAceptarTerminos)) {
                        echo '<span class="faltanCampos">' . $faltaAceptarTerminos . '</span> <br>';
                    }
                ?>

                <input type="submit" value="Enviar" name="submit">

                <p class='enviado'><?php echo $mensajeComentarioEnviado; ?></p>
            </form>
        </div>
    </main>

    <div id="cookie-message" class="cookie-notification">
        <p>Este sitio web utiliza cookies que ayudan al funcionamiento del sitio web y para rastrear cómo interactúa con él para que podamos brindarle una experiencia de usuario mejorada y personalizada.</p>
        <button id="accept-cookies-btn">Aceptar</button>

        <script src="js/aceptarCookies.js"></script>
    </div>

    <footer>
        <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
    </footer>
</body>

</html>