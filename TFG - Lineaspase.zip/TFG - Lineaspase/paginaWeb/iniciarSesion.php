<?php include "conexionBD.php"; ?>
<?php
    session_start();
    header("Cache-Control: no-cache, no-store, must-revalidate");
    header("Pragma: no-cache");
    header("Expires: 0");
    session_destroy();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Iniciar sesión</title>

    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/iniciarSesion.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/textosLegales.html">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/nosotros.html">NOSOTROS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/iniciarSesion.php" class="paginaActiva">Iniciar sesión</a>
                </li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="contenidoPrincipal">
            <h1>INICIA SESIÓN</h1>

            <div class="botonesInicioRegistrarse">
                <a href="https://www.lineaspase.com/iniciarSesion.php">
                     <button class="botonIniciarSesion">Inicia sesión</button>
                </a>
                <a href="https://www.lineaspase.com/registrarse.php">
                    <button class="botonRegistrarse">Regístrate</button>
                </a>
            </div>

            <?php
                $inicioIncorrecto = "";

                $faltaNombreUsuario = "";
                $faltaContrasena = "";
                
                $nombreUsuario = "";
                $contrasena = "";

                function limpiarCaracteres($datos) {
                    $datos = trim($datos);
                    $datos = stripslashes($datos);
                    $datos = htmlspecialchars($datos);
                    return $datos;
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $nombreUsuario = limpiarCaracteres($_POST["nombreUsuario"]);
                    $contrasena = limpiarCaracteres($_POST["contrasena"]);

                    if ((empty($faltaNombreUsuario)) || (!(empty($faltaNombreUsuario)))) {
                        $cifrarContrasena = md5($contrasena);
                        $consultarUsuario = "SELECT nombre AS 'nombre', primer_apellido AS 'primerApellido', segundo_apellido AS 'segundoApellido', nombre_usuario AS 'nombreUsuario', contrasena AS 'contrasena', rol AS 'rol', telefono AS 'telefono', nif AS 'dni', email AS 'email' FROM clientes WHERE nombre_usuario LIKE '$nombreUsuario' AND contrasena LIKE '$cifrarContrasena'";
                        $resultadoConsultarUsuario = mysqli_query($enlace, $consultarUsuario);

                        if (mysqli_num_rows($resultadoConsultarUsuario) == 1) {
                            $fila = mysqli_fetch_assoc($resultadoConsultarUsuario);
                            $rolUsuario = mysqli_real_escape_string($enlace, $fila["rol"]);
                            $nombreUsuario = mysqli_real_escape_string($enlace, $fila["nombreUsuario"]);
                            $nombre = mysqli_real_escape_string($enlace, $fila["nombre"]);
                            $primerApellido = mysqli_real_escape_string($enlace, $fila["primerApellido"]);
                            $segundoApellido = mysqli_real_escape_string($enlace, $fila["segundoApellido"]);
                            $dni = mysqli_real_escape_string($enlace, $fila["dni"]);
                            $telefono = mysqli_real_escape_string($enlace, $fila["telefono"]);
                            $email = mysqli_real_escape_string($enlace, $fila["email"]);

                            if ($rolUsuario == "Cliente") {
                                session_start();
                                $_SESSION['loggedin'] = true;
                                $_SESSION['rol'] = $rolUsuario;
                                $_SESSION["nombreUsuario"] = $nombreUsuario;
                                $_SESSION["nombre"] = $nombre;
                                $_SESSION["primerApellido"] = $primerApellido;
                                $_SESSION["segundoApellido"] = $segundoApellido;
                                $_SESSION["dni"] = $dni;
                                $_SESSION["telefono"] = $segundoApellido;
                                $_SESSION["email"] = $email;
                                setcookie('rol', $rolUsuario, [
                                    'expires' => time() + 86400,
                                    'path' => '/',
                                    'secure' => true,
                                    'httponly' => true
                                ]);
                                echo "<script>window.location='https://www.lineaspase.com/areaClientes-index.php'</script>";
                            } elseif ($rolUsuario == "Administrador") {
                                session_start();
                                $_SESSION['loggedin'] = true;
                                $_SESSION['rol'] = $rolUsuario;
                                $_SESSION["nombreUsuario"] = $nombreUsuario;
                                $_SESSION["nombre"] = $nombre;
                                $_SESSION["primerApellido"] = $primerApellido;
                                $_SESSION["segundoApellido"] = $segundoApellido;
                                $_SESSION["dni"] = $dni;
                                $_SESSION["telefono"] = $segundoApellido;
                                $_SESSION["email"] = $email;
                                setcookie('rol', $rolUsuario, [
                                    'expires' => time() + 86400,
                                    'path' => '/',
                                    'secure' => true,
                                    'httponly' => true
                                ]);
                                echo "<script>window.location='https://www.lineaspase.com/areaAdministradores-index.php'</script>";
                            }
                        } else {
                            $inicioIncorrecto = sprintf('<span style="color: red;">*Nombre de Usuario o Contraseña incorrectos.</span>');
                            mysqli_close($enlace);
                        }
                    }
                }
            ?>

            <form method="POST" action="<?php echo limpiarCaracteres($_SERVER["PHP_SELF"]); ?>">
                <label for="nombreUsuario">Nombre de Usuario:</label>
                <input type="text" name="nombreUsuario" id="nombreUsuario" placeholder="Escribe aquí tu Nombre de Usuario."> <br>

                <label for="contrasena">Contraseña:</label>
                <input type="password" name="contrasena" id="contrasena" placeholder="Escribe aquí tu Contraseña."> <br>

                <input type="submit" name="enviar" id="enviar" value="Iniciar sesión"> <span><?php echo $inicioIncorrecto; ?></span> <br>

                <span class="enlaceContacto"> <a href="https://www.lineaspase.com/recuperarContrasena.php">¿Has olvidad la Contraseña?</a> </span>
            </form>
        </div>
    </main>

    <div id="cookie-message" class="cookie-notification">
        <p>Este sitio web utiliza cookies que ayudan al funcionamiento del sitio web y para rastrear cómo interactúa con él para que podamos brindarle una experiencia de usuario mejorada y personalizada.</p>
        <button id="accept-cookies-btn">Aceptar</button>

        <script src="js/aceptarCookies.js"></script>
    </div>

    <footer>
        <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
    </footer>
</body>

</html>

<?php
    mysqli_close($enlace);
?>