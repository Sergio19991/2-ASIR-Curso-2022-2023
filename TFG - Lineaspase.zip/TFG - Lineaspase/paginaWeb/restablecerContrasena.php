<?php include "conexionBD.php"; ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Restablecer Contraseña</title>

    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/recuperarContrasena.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/textosLegales.html">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/nosotros.html">NOSOTROS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/iniciarSesion.php" class="paginaActiva">Iniciar sesión</a>
                </li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="contenidoPrincipal">
            <h1>RESTABLECER CONTRASEÑA</h1>

            <?php
                function limpiarCaracteres($datos) {
                    $datos = trim($datos);
                    $datos = stripslashes($datos);
                    $datos = htmlspecialchars($datos);
                    return $datos;
                }

                if ((isset($_GET['dni'])) && (isset($_GET['token']))) {
                    $dniUrl = limpiarCaracteres($_GET['dni']);
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $dni = limpiarCaracteres($_POST["dni"]);
                    $contrasena = limpiarCaracteres($_POST["contrasena"]);
                    $repetirContrasena = limpiarCaracteres($_POST["repetirContrasena"]);
                    $dniUrl = limpiarCaracteres($_POST["dniUrl"]);
                    $nombreUsuario = limpiarCaracteres($_POST["nombreUsuario"]);
                    $primerApellidoUsuario = limpiarCaracteres($_POST["primerApellidoUsuario"]);
                    $segundoApellidoUsuario = limpiarCaracteres($_POST["segundoApellidoUsuario"]);

                    if (empty($contrasena)) {
                        $faltaContrasena = "*Debes de escribir una Contraseña.";
                    } elseif ((strlen($contrasena) < 8) || (!preg_match('/[A-Z]/', $contrasena)) || (!preg_match('/[a-z]/', $contrasena)) || (!preg_match('/[0-9]/', $contrasena)) || (!preg_match('/[\W]/', $contrasena))) {
                        $faltaContrasena = "*La Contraseña que has introducido no cumple con los Requisitos Mínimos. (Debe tener, al menos, 8 Dígitos, una Letra Minúscula, una Letra Mayúscula, un Número y un Carácter Especial).";
                    }

                    if (empty($repetirContrasena)) {
                        $faltaRepetirContrasena = "*Debes de introducir la misma Contraseña.";
                    } elseif (!($contrasena === $repetirContrasena)) {
                        $faltaRepetirContrasena = "*Las Contraseñas no coinciden.";
                        $faltaContrasena = "*Las Contraseñas no coinciden.";
                    }

                    if ((empty($faltaContrasena)) && (empty($faltaRepetirContrasena))) {
                        $contrasenaCifrada = md5($contrasena);
                        $consultaCambiarContrasena = "UPDATE clientes
                                                      SET contrasena = '$contrasenaCifrada'
                                                      WHERE clientes.nif LIKE '$dni'";
                        $resultadoCambiarContrasena = mysqli_query($enlace, $consultaCambiarContrasena);

                        if ($resultadoCambiarContrasena) {
                            $mensajeContrasena = 'Tu contraseña ha sido cambiado correctamente. Haz clic <a href="https://www.lineaspase.com/iniciarSesion.php">aquí</a> para Iniciar Sesión.';
                        } else {
                            $errorCambiarContrasena = "No ha sido posible cambiar tu Contraseña en estos momentos. Por favor, vuélvelo a intentarlo más tarde o póngase en contacto haciendo clic <a href='https://www.lineaspase.com/contacto.php'>aquí</a>.";
                        }
                    }
                }
            ?>

            <?php
                $consultarUsuario = "SELECT clientes.nombre AS 'nombre', clientes.primer_apellido AS 'primerApellido', clientes.segundo_apellido AS 'segundoApellido'
                                     FROM clientes
                                     WHERE nif LIKE '{$dniUrl}'";
                $resultadoConsultarUsuario = mysqli_query($enlace, $consultarUsuario);

                if ($resultadoConsultarUsuario) {
                    $fila = mysqli_fetch_assoc($resultadoConsultarUsuario);

                    $nombreUsuario = mysqli_real_escape_string($enlace, $fila['nombre']);
                    $primerApellidoUsuario = mysqli_real_escape_string($enlace, $fila['primerApellido']);
                    $segundoApellidoUsuario = mysqli_real_escape_string($enlace, $fila['segundoApellido']);
                }

                echo '<p class="saludarUsuario">Hola, ' . $nombreUsuario . ' ' . $primerApellidoUsuario .  ' ' . $segundoApellidoUsuario .'. A continuación, puede restablecer tu Contraseña:</p>';
            ?>

            <form method="POST" action="<?php echo limpiarCaracteres($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="nombreUsuario" value="<?php echo $nombreUsuario; ?>">
                <input type="hidden" name="primerApellidoUsuario" value="<?php echo $primerApellidoUsuario; ?>">
                <input type="hidden" name="segundoApellidoUsuario" value="<?php echo $segundoApellidoUsuario; ?>">

                <label for="dni">DNI:</label>
                <input type="text" name="dni" id="dni" placeholder="Escribe aquí tu DNI." value="<?php echo $dniUrl; ?>" readonly>
                <input type="hidden" name="dniUrl" value="<?php echo $dniUrl; ?>">
                <?php
                    if (!empty($faltaDni)) {
                        echo '<span class="faltanCampos">' . $faltaDni . '</span> <br>';
                    }
                ?>

                <label for="contrasena">Contraseña:</label>
                <input type="password" name="contrasena" id="contrasena" placeholder="Escribe aquí tu nueva Contraseña.">
                <?php
                    if (!empty($faltaContrasena)) {
                        echo '<span class="faltanCampos">' . $faltaContrasena . '</span> <br>';
                    }
                ?>

                <label for="contrasena">Repetir Contraseña:</label>
                <input type="password" name="repetirContrasena" id="repetirContrasena" placeholder="Vulve a escribir aquí la misma Contraseña.">
                <?php
                    if (!empty($faltaRepetirContrasena)) {
                        echo '<span class="faltanCampos">' . $faltaRepetirContrasena . '</span> <br>';
                    }
                ?>

                <input type="submit" value="Enviar">
                <a href="https://www.lineaspase.com/iniciarSesion.php" class="botonVolver">Cancelar</a> <br>

                <?php
                    echo "<span class='mensajeContrasena'>$mensajeContrasena</span>";
                    echo "<span class='errorCambiarContrasena'>$errorCambiarContrasena</span>";
                ?>
            </form>
        </div>
    </main>

    <footer>
        <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
    </footer>
</body>

</html>

<?php
    mysqli_close($enlace);
?>