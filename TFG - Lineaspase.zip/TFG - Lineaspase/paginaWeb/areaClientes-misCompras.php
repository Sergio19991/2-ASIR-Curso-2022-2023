<?php include "conexionBD.php"; ?>

<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Cliente') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
        $dni = $_SESSION["dni"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Mis compras</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/misCompras.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/cajasDesplegables.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaClientes-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaClientes-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaClientes-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaClientes-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaClientes-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaClientes-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>

    <body>
        <main>

            <div class="contenidoPrincipal">

                <h1 class="titulo">MIS COMPRAS</h1>

                <?php
                    $consultarCompras = "SELECT tickets.codigo AS 'codigoTicket', tickets.linea AS 'nombreLinea', tickets.precio AS 'precio', tickets.cantidad AS 'cantidad', tickets.precio * tickets.cantidad AS 'precioTotal', tickets.fecha_compra AS 'fechaCompra', tickets.hora_compra AS 'horaCompra', tickets.numero_referencia AS 'numeroReferencia'
                                         FROM clientes
                                         JOIN tickets ON clientes.nif = tickets.nif_clientes
                                         WHERE tickets.nif_clientes LIKE '{$dni}'
                                         ORDER BY tickets.fecha_compra ASC";
                    $resultadoConsultarCompras = mysqli_query($enlace, $consultarCompras);

                    if($resultadoConsultarCompras) {
                        if (mysqli_num_rows($resultadoConsultarCompras) > 0) {
                            $fila = mysqli_fetch_assoc($resultadoConsultarCompras);

                            $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                            $precio = mysqli_real_escape_string($enlace, $fila['precio']);
                            $cantidad = mysqli_real_escape_string($enlace, $fila['cantidad']);
                            $precioTotal = mysqli_real_escape_string($enlace, $fila['precioTotal']);
                            $fechaCompra = mysqli_real_escape_string($enlace, $fila['fechaCompra']);
                            $horaCompra = mysqli_real_escape_string($enlace, $fila['horaCompra']);
                            $numeroReferencia = mysqli_real_escape_string($enlace, $fila['numeroReferencia']);
                            $codigoTicket = mysqli_real_escape_string($enlace, $fila['codigoTicket']);
    
                            $fechaCompraObjeto = date_create_from_format('Y-m-d', $fechaCompra);
                            $fechaCompraObjetoFormateada = $fechaCompraObjeto->format('d/m/Y');
    
                            echo "<table class='table table-striped table-hover'>";
    
                            echo "<tr>";
                            echo "  <th>Línea:</th>";
                            echo "  <th>Precio:</th>";
                            echo "  <th>Cantidad:</th>";
                            echo "  <th>Total (IVA Incluido):</th>";
                            echo "  <th>Fecha y Hora:</th>";
                            echo "  <th>Referencia:</th>";
                            echo "</tr>";
    
                            echo "<tr>";
                            echo '  <td>' . $nombreLinea . '</td>';
                            echo '  <td>' . number_format($precio, 2, ',', '.') . '€</td>';
                            echo '  <td>' . $cantidad . '</td>';
                            echo '  <td>' . number_format($precioTotal, 2, ',', '.') . '€</td>';
                            echo '  <td>' . $fechaCompraObjetoFormateada . ' - ' . $horaCompra . '</td>';
                            echo "  <td><a href='https://www.lineaspase.com/areaClientes-imprimirTicket.php?numeroReferencia={$numeroReferencia}' title='Volver a imprimir el Ticket' class='verTicket'>#$numeroReferencia</a></td>";
                            echo "</tr>";
    
                            while ($fila = mysqli_fetch_assoc($resultadoConsultarCompras)) {
                                $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                                $precio = mysqli_real_escape_string($enlace, $fila['precio']);
                                $cantidad = mysqli_real_escape_string($enlace, $fila['cantidad']);
                                $precioTotal = mysqli_real_escape_string($enlace, $fila['precioTotal']);
                                $fechaCompra = mysqli_real_escape_string($enlace, $fila['fechaCompra']);
                                $horaCompra = mysqli_real_escape_string($enlace, $fila['horaCompra']);
                                $numeroReferencia = mysqli_real_escape_string($enlace, $fila['numeroReferencia']);
    
                                echo "<tr>";
                                echo '  <td>' . $nombreLinea . '</td>';
                                echo '  <td>' . number_format($precio, 2, ',', '.') . '€</td>';
                                echo '  <td>' . $cantidad . '</td>';
                                echo '  <td>' . number_format($precioTotal, 2, ',', '.') . '€</td>';
                                echo '  <td>' . $fechaCompraObjetoFormateada . ' - ' . $horaCompra . '</td>';
                                echo "  <td><a href='https://www.lineaspase.com/areaClientes-imprimirTicket.php?numeroReferencia={$numeroReferencia}' title='Volver a imprimir el Ticket' class='verTicket'>#$numeroReferencia</a></td>";
                                echo "</tr>";
                            }
    
                            echo "</table>";  
                        } else {
                            echo "<p class='sinCompras'>Aún no has comprando ningún Billete.<p>";
                        }
                    } else {
                        echo "<p class='mensajeError'>Lo sentimos, no hemos podido recuperar tus compras. Por favor, inténtelo de nuevo más tardeo o póngase en contacto haciendo clic <a href='https://www.lineaspase.com/areaClientes-contacto.php'>aquí</a>. (Recuerda facilitarnos tu Nombre de Usuario, así como tu DNI).</p>";
                    }
                ?>
            </div>

        </main>

        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
        
    </body>

</html>

<?php
    mysqli_close($enlace);
?>