<?php include "conexionBD.php"; ?>

<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Cliente') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Rutas y Horarios</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/rutasHorarios.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/cajasDesplegables.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaClientes-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaClientes-rutasHorarios.php" class="paginaActiva">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaClientes-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaClientes-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaClientes-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaClientes-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>
        <main>
            <div class="contenidoPrincipal">
                <h1>RUTAS Y HORARIOS</h1>

                <?php /* LINEA L-1: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-1'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/areaClientes-comprar.php?codigoLineaURL={$codigoLinea}' class='botonesComprar' title='Proceder con la compra'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-2: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-2'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/areaClientes-comprar.php?codigoLineaURL={$codigoLinea}' class='botonesComprar' title='Proceder con la compra'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-3: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-3'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/areaClientes-comprar.php?codigoLineaURL={$codigoLinea}' class='botonesComprar' title='Proceder con la compra'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-4: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-4'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/areaClientes-comprar.php?codigoLineaURL={$codigoLinea}' class='botonesComprar' title='Proceder con la compra'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-5: */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-5'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/areaClientes-comprar.php?codigoLineaURL={$codigoLinea}' class='botonesComprar' title='Proceder con la compra'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>

                <?php /* LINEA L-6 */
                    $consultarLineasRutas = "SELECT lineas.codigo AS 'codigoLinea', lineas.nombre AS 'nombreLinea', lo.nombre AS 'localidadOrigenNombre', lo.ciudad AS 'localidadOrigenCiudad', ld.nombre AS 'localidadDestinoNombre', ld.ciudad AS 'localidadDestinoCiudad', DATE_FORMAT(lineas.hora_salida, '%H:%i') AS 'horaSalida', DATE_FORMAT(lineas.hora_llegada, '%H:%i') AS 'horaLlegada', REPLACE(billetes.precio_venta, '.', ',') AS 'precioBillete'
                                             FROM lineas, localidad lo, localidad ld, billetes
                                             WHERE lineas.localidad_origen = lo.codigo AND lineas.localidad_destino = ld.codigo AND lineas.codigo = billetes.codigo AND lineas.nombre LIKE 'L-6'
                                             ORDER BY lineas.hora_salida";
                    $resultadoLineasRutas = mysqli_query($enlace, $consultarLineasRutas);

                    if($resultadoLineasRutas) {
                        $fila = mysqli_fetch_assoc($resultadoLineasRutas);

                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $localidadOrigenNombre = mysqli_real_escape_string($enlace, $fila['localidadOrigenNombre']);
                        $localidadOrigenCiudad = mysqli_real_escape_string($enlace, $fila['localidadOrigenCiudad']);
                        $localidadDestinoNombre = mysqli_real_escape_string($enlace, $fila['localidadDestinoNombre']);
                        $localidadDestinoCiudad = mysqli_real_escape_string($enlace, $fila['localidadDestinoCiudad']);
                        $precioBillete = mysqli_real_escape_string($enlace, $fila['precioBillete']);
                        $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                        $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                        
                        echo "<div class='caja'>
                                <div class='titulo' onclick='toggleCaja(this)'>{$nombreLinea}: {$localidadOrigenNombre}({$localidadOrigenCiudad}) - {$localidadDestinoNombre}({$localidadDestinoCiudad})</div>
                                    <div class='contenido'>
                                        <table>
                                        <tr>
                                            <th>Horas de Salida</th>
                                            <th>Horas de Llegada</th>
                                        </tr>";

                                        echo "<tr>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaSalida"]) . "h</td>";
                                        echo "<td>" . mysqli_real_escape_string($enlace, $fila["horaLlegada"]) . "h</td>";

                                        while ($fila = mysqli_fetch_assoc($resultadoLineasRutas)) {
                                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);
                                            echo "<tr>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "<td>" . $horaSalida . "h</td>";
                                            echo "</tr>";
                                        }

                        echo "          </table>
                                        <a href='https://www.lineaspase.com/areaClientes-comprar.php?codigoLineaURL={$codigoLinea}' class='botonesComprar' title='Proceder con la compra'><p>COMPRAR BILLETES ({$precioBillete}€)<p></a>
                                        <p class='advertenciaHorario'>(*Horario aproximado salvo dificultades de tráfico)</p>
                                    </div>
                              </div>";
                    } else {
                        echo "<p>Lo sentimos, se ha producio un error al cargar la Información. Por favor, vuelva a intentarlo más tarde o póngase en contacto a través de <a href='https://www.lineaspase.com/contacto.php'>este enlace</a>. Gracias, y disculpe las molestias.<p>";
                    }
                ?>
            </div>
        </main>
        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
</body>
</html>

<?php
    mysqli_close($enlace);
?>