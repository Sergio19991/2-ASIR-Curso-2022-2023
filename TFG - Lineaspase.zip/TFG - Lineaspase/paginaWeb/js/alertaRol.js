/* Función para la Alerta de Cambio de Rol al Crear un nuevo Usuaro desde el Área de Administradores:*/
function mostrarAlertaRolModificadoCrearUsuarios() {
    var select = document.getElementById("rol");
    var opcionSeleccionada = select.options[select.selectedIndex].value;
    var nombreUsuario = document.getElementById("nombreUsuario").value;

    if (nombreUsuario !== "") {
        if (opcionSeleccionada === "Administrador") {
            alert("Le va asignar el Rol de Administrador a " + nombreUsuario + ". Esto puede causar graves problemas de Seguridad.");
        }
    }
}





                        /* © Sergio Bejarano Arroyo */