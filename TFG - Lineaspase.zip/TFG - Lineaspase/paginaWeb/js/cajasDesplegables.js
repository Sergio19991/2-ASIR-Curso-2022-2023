var cajas = document.getElementsByClassName('caja');

function toggleCaja(elemento) {
  var contenido = elemento.nextElementSibling;
  var isVisible = contenido.style.display === 'block';

  for (var i = 0; i < cajas.length; i++) {
    var cajaContenido = cajas[i].getElementsByClassName('contenido')[0];
    cajaContenido.style.display = 'none';
  }

  if (!isVisible) {
    contenido.style.display = 'block';
  }
}

for (var i = 0; i < cajas.length; i++) {
  var titulo = cajas[i].getElementsByClassName('titulo')[0];
  titulo.onclick = function () {
    toggleCaja(this);
  };
}





                        /* © Sergio Bejarano Arroyo */