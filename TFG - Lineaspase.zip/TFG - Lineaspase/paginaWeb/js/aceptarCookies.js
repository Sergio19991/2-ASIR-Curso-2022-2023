function hideCookieNotification() {
    var cookieMessage = document.getElementById("cookie-message");
    if (cookieMessage) {
        cookieMessage.style.display = "none";
    }
}

function saveCookiePreference() {
    var expirationDate = new Date();
    expirationDate.setFullYear(expirationDate.getFullYear() + 1);
    localStorage.setItem("cookieAccepted", "true");
    document.cookie = "cookieAccepted=true; expires=" + expirationDate.toUTCString() + "; path=/";
    hideCookieNotification();
}

var cookieAccepted = localStorage.getItem("cookieAccepted");
if (cookieAccepted === "true") {
    hideCookieNotification();
} else {
    var acceptCookiesBtn = document.getElementById("accept-cookies-btn");
    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener("click", saveCookiePreference);
    }
}





                        /* © Sergio Bejarano Arroyo */