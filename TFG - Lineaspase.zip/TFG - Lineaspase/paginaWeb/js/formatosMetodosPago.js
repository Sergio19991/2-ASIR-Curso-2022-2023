function formatCreditCardNumber(input) {
  let value = input.value.replace(/\s/g, "");
  let formattedValue = "";

  for (let i = 0; i < value.length; i++) {
    if (i > 0 && i % 4 === 0) {
      formattedValue += " ";
    }
    formattedValue += value[i];
  }
  input.value = formattedValue;
}

function onlyNumbers(event) {
  const key = event.key;
  return /^[0-9]+$/.test(key);
}

function validateDate(event) {
  const key = event.key;
  const currentValue = event.target.value;

  if (currentValue.length === 2 && key !== '/') {
    event.target.value = currentValue + '/';
  }

  if (currentValue.length >= 7) {
    event.preventDefault();
  } else {
    if (!/^[0-9/]+$/.test(key)) {
      event.preventDefault();
    }
  }
}





                        /* © Sergio Bejarano Arroyo */