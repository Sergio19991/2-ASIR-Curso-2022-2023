function confirmacionEliminar() {
    var nombreUsuario = document.getElementById("modificarNombreUsuario").value;

        var respuesta = confirm("¿Realmente desea eliminar al Usuario " + nombreUsuario + "?");
        if (respuesta == true) {
            return true;
        } else {
            return false;
        }
}





                        /* © Sergio Bejarano Arroyo */