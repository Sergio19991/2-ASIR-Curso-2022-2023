function imprimirTicket() {
    var contenidoTicket = document.querySelector('.ticketCompra').innerHTML;
    var ventanaImpresion = window.open('', '_blank');
    ventanaImpresion.document.write('<html><head><title>Ticket de Compra</title>');
    ventanaImpresion.document.write('<style>.ticketCompra { margin: 0 auto; border: solid 3px #51933e; border-radius: 6px; padding: 15px; margin-bottom: 30px; width: 70%; font-family: sans-serif; font-size: 15px; background-color: #f9ffe1; } .ticketCompra ul { margin-left: 10%; } .autorCompra { text-align: center; margin-bottom: 0px; }</style>');
    ventanaImpresion.document.write('</head><body>');
    ventanaImpresion.document.write(contenidoTicket);
    ventanaImpresion.document.write('</body></html>');
    ventanaImpresion.document.close();
    ventanaImpresion.print();
    ventanaImpresion.close();
}





                        /* © Sergio Bejarano Arroyo */