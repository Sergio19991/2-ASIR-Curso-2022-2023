<?php include "conexionBD.php"; ?>

<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
        $email = $_SESSION["email"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Ticket de Compra</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/ticket.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/imprimirTicket.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php">USUARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-flota.php">FLOTA</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>
        <main>
            <div class="contenidoPrincipal">
        
                <h1>TICKET DE COMPRA</h1>

                    <?php
                        function limpiarCaracteres($datos) {
                            $datos = trim($datos);
                        $datos = stripslashes($datos);
                            $datos = htmlspecialchars($datos);
                            return $datos;
                        }
                    
                        if ((isset($_GET['codigoComprar']) & (isset($_GET['fechaSeleccionada'])) && (isset($_GET['horaCompra'])))) {
                            $codigoComprar = limpiarCaracteres($_GET['codigoComprar']);
                            $fechaSeleccionadaURL = limpiarCaracteres($_GET['fechaSeleccionada']);
                            $horaCompra = limpiarCaracteres($_GET['horaCompra']);
                        }

                        $consultaTicket = "SELECT comprar.fecha_compra AS 'fechaCompra',comprar.cantidad AS 'cantidad', clientes.nombre AS 'nombreCliente', clientes.primer_apellido AS 'primerApellidoCliente', clientes.segundo_apellido AS 'segundoApellidoCliente', clientes.nif AS 'dniCliente', billetes.precio_venta AS 'precioVenta', comprar.cantidad * billetes.precio_venta AS 'precioTotal', lineas.nombre AS 'nombreLinea', lineas.hora_salida AS 'horaSalida', lineas.hora_llegada AS 'horaLlegada',lo.nombre AS 'nombreLocalidadOrigen', lo.ciudad AS 'nombreCiudadOrigen', lo.nombre_estacion AS 'nombreEstacionOrigen', ld.nombre AS 'nombreLocalidadDestino', ld.ciudad AS 'nombreCiudadDestino', ld.nombre_estacion AS 'nombreEstacionDestino'
                                           FROM comprar
                                           JOIN clientes ON comprar.nif_clientes = clientes.nif
                                           JOIN billetes ON comprar.codigo_billete = billetes.codigo
                                           JOIN lineas ON billetes.codigo_linea = lineas.codigo
                                           JOIN localidad AS lo ON lineas.localidad_origen = lo.codigo
                                           JOIN localidad AS ld ON lineas.localidad_destino = ld.codigo
                                           WHERE comprar.codigo = {$codigoComprar}";
                        $resultadoConsultaTicket = mysqli_query($enlace, $consultaTicket);


                        if($resultadoConsultaTicket) {
                            $fila = mysqli_fetch_assoc($resultadoConsultaTicket);

                            $fechaCompra = mysqli_real_escape_string($enlace, $fila['fechaCompra']);
                            $cantidad = mysqli_real_escape_string($enlace, $fila['cantidad']);
                            $nombreCliente = mysqli_real_escape_string($enlace, $fila['nombreCliente']);
                            $primerApellidoCliente = mysqli_real_escape_string($enlace, $fila['primerApellidoCliente']);
                            $segundoApellidoCliente = mysqli_real_escape_string($enlace, $fila['segundoApellidoCliente']);
                            $dniCliente = mysqli_real_escape_string($enlace, $fila['dniCliente']);
                            $precioVenta = mysqli_real_escape_string($enlace, $fila['precioVenta']);
                            $precioTotal = mysqli_real_escape_string($enlace, $fila['precioTotal']);
                            $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                            $nombreLocalidadOrigen = mysqli_real_escape_string($enlace, $fila['nombreLocalidadOrigen']);
                            $nombreCiudadOrigen = mysqli_real_escape_string($enlace, $fila['nombreCiudadOrigen']);
                            $nombreEstacionOrigen = mysqli_real_escape_string($enlace, $fila['nombreEstacionOrigen']);
                            $nombreLocalidadDestino = mysqli_real_escape_string($enlace, $fila['nombreLocalidadDestino']);
                            $nombreCiudadDestino = mysqli_real_escape_string($enlace, $fila['nombreCiudadDestino']);
                            $nombreEstacionDestino = mysqli_real_escape_string($enlace, $fila['nombreEstacionDestino']);
                            $horaSalida = mysqli_real_escape_string($enlace, $fila['horaSalida']);
                            $horaLlegada = mysqli_real_escape_string($enlace, $fila['horaLlegada']);

                            $fechaSeleccionadaObjeto = date_create_from_format('Y-m-d', $fechaSeleccionadaURL);
                            $fechaSeleccionadaObjetoFormateada = $fechaSeleccionadaObjeto->format('d/m/Y');

                            $fechaCompraObjeto = date_create_from_format('Y-m-d', $fechaCompra);
                            $fechaCompraObjetoFormateada = $fechaCompraObjeto->format('d/m/Y');

                            $precioFormateado = number_format($precioVenta, 2, ',', '.');
                            $precioTotalFormateado = number_format(($precioVenta * $cantidad), 2, ',', '.');
                            
                            echo '<p class="informacionTicket">A continuación puede imprimir su Ticket y mostrárselo al Chofer. Gracias y que tenga un buen viaje.</p>';
                            echo '<div class="ticketCompra">';
                            echo '  <ul>';
                            echo '      <li>Línea ' . $nombreLinea . ' : ' . $nombreLocalidadOrigen . ' (' . $nombreCiudadOrigen . ') - ' . $nombreLocalidadDestino . ' (' . $nombreCiudadDestino .')</li>';
                            echo '      <li>Fecha y Hora de Salida: ' . $fechaSeleccionadaObjetoFormateada . ' - ' . $horaSalida . '. (Estación: "' . $nombreEstacionOrigen . '").</li>';
                            echo '      <li>Fecha y Hora de Llegada: ' . $fechaSeleccionadaObjetoFormateada . ' - ' . $horaLlegada . '. (Estación: "' . $nombreEstacionDestino . '").</li>';
                            echo '      <li>Cantidad de Billetes: ' . $cantidad . '. (Por ' . $precioFormateado . '€ cada uno).</li>';
                            echo '      <li>Total: ' . $precioTotalFormateado . '€. (IVA incluido).</li>';
                            echo '  </ul>';
                            echo '<p class="autorCompra">Compra realizada el ' . $fechaCompraObjetoFormateada . ' a las ' . $horaCompra . ' por ' . $nombre . ' ' . $primerApellidoCliente . ' ' . $segundoApellidoCliente . ' (' . $dniCliente . ').</p>';
                            echo '</div>';
                            echo '<div class="botonImprimir">';
                            echo '  <button onclick="imprimirTicket()">IMPRIMIR</button>';
                            echo '<div>';
                            echo '<div class="botonImprimir">';
                            echo '  <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php" class="botonVolver" title="Volver a Rutas y Horarios">Volver</a>';
                            echo '<div>';

                            $destinatario = $email;
                            $encabezado = 'Buen Viaje';
                            $cuerpoMensaje = 'Línea ' . $nombreLinea . ' : ' . $nombreLocalidadOrigen . ' (' . $nombreCiudadOrigen . ') - ' . $nombreLocalidadDestino . ' (' . $nombreCiudadDestino . ')' . "\r\n" .
                            'Fecha y Hora de Salida: ' . $fechaSeleccionadaObjetoFormateada . ' : ' . $horaSalida . ' (Estación: "' . $nombreEstacionOrigen . ').' . "\r\n" .
                            'Fecha y Hora de Llegada: ' . $fechaSeleccionadaObjetoFormateada . ' : ' . $horaLlegada . ' (Estación: "' . $nombreEstacionDestino . ').' . "\r\n" .
                            'Cantidad de Billetes: ' . $cantidad . '. (Por ' . $precioFormateado . '€ cada uno).' . "\r\n" .
                            'Total: ' . $precioTotalFormateado . '€. (IVA incluido).';

                            $headers = 'From: lineaspase@lineaspase.com' . "\r\n" .
                                    'Reply-To: lineaspase@lineaspase.com' . "\r\n" .
                                    'X-Mailer: PHP/' . phpversion();
                                    mail($destinatario, $encabezado, $cuerpoMensaje, $headers);
                        } else {
                            echo '<div class="ticketCompra">'; 
                            echo '  <p class="mensajeError">En estos momentos no ha sido posible mostrarle el Ticket. Por favor, póngase en contacto haciendo clic <a href="areaAdministradores-contacto.php">aquí</a>. Indicando su Número de Tcket (<span class="numeroTicket">' . $codigoComprar . '</span>), así como su DNI.</p>';
                            echo '</div>';
                        }
                    ?>
            </div>
        </main>
        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
</body>
</html>


<?php
    mysqli_close($enlace);
?>