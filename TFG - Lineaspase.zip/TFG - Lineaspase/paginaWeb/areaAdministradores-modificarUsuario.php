<?php include "conexionBD.php"; ?>

<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Modificar Usuario</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/modificarUsuarios.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/alertaRol.js"></script>
    <script src="js/soloNumeros.js"></script>
    <script src="js/confirmacionEliminar.js"></script>
    <script src="js/mostrarOcultarCajaDeslizante.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php" class="paginaActiva">USUARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-flota.php">FLOTA</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>
        <main>
            <div class="contenidoPrincipal">
                <h1>MODIFICAR USUARIO</h1>

            <?php
                function limpiarCaracteres($datos) {
                    $datos = trim($datos);
                    $datos = stripslashes($datos);
                    $datos = htmlspecialchars($datos);
                    return $datos;
                }

                if (isset($_GET['dniUsuarioURL'])) {
                    $dniUsuarioURL = limpiarCaracteres($_GET['dniUsuarioURL']);
                }

                $consultarUsuario = "SELECT nif AS 'dni', nombre AS 'nombre', primer_apellido AS 'primerApellido', segundo_apellido AS 'segundoApellido', fecha_nacimiento AS 'fechaNacimiento', telefono AS 'telefono', email AS 'correoElectrónico', nombre_usuario AS 'nombreUsuario', rol AS 'rol'
                                     FROM clientes
                                     WHERE nif LIKE '{$dniUsuarioURL}'";
                $resultadoConsultarUsuario = mysqli_query($enlace, $consultarUsuario);

                if($resultadoConsultarUsuario) {
                    $fila = mysqli_fetch_assoc($resultadoConsultarUsuario);

                    $dni = mysqli_real_escape_string($enlace, $fila['dni']);
                    $nombre = mysqli_real_escape_string($enlace, $fila['nombre']);
                    $primerApellido = mysqli_real_escape_string($enlace, $fila['primerApellido']);
                    $segundoApellido = mysqli_real_escape_string($enlace, $fila['segundoApellido']);
                    $fechaNacimiento = mysqli_real_escape_string($enlace, $fila['fechaNacimiento']);
                    $telefono = mysqli_real_escape_string($enlace, $fila['telefono']);
                    $email = mysqli_real_escape_string($enlace, $fila['correoElectrónico']);
                    $nombreUsuario = mysqli_real_escape_string($enlace, $fila['nombreUsuario']);
                    $rol = mysqli_real_escape_string($enlace, $fila['rol']);
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $nombre = limpiarCaracteres($_POST["nombre"]);
                    $primerApellido = limpiarCaracteres($_POST["primerApellido"]);
                    $segundoApellido = limpiarCaracteres($_POST["segundoApellido"]);
                    $dni = limpiarCaracteres($_POST["dni"]);
                    $fechaNacimiento = limpiarCaracteres($_POST["fechaNacimiento"]);
                    $telefono = limpiarCaracteres($_POST["telefono"]);
                    $email = limpiarCaracteres($_POST["email"]);
                    $nombreUsuario = limpiarCaracteres($_POST["nombreUsuario"]);
                    $rol = limpiarCaracteres($_POST["rol"]);
                    $aceptarTerminos = limpiarCaracteres($_POST["aceptarTerminos"]);

                    if (empty($nombre)) {
                        $faltaNombre = "*Debes escribir tu Nombre.";
                    } elseif (strlen($nombre) > 25) {
                        $faltaNombreUsuario = "*El Nombre que has introducido no puede contener más de 25 Carácteres.";
                    }

                    if (empty($primerApellido)) {
                        $faltaPrimerApellido = "*Debes escribir tu Primer Apellido.";
                    } elseif (strlen($primerApellido) > 25) {
                        $faltaPrimerApellido = "*El Primer Apellido que has introducido no puede contener más de 25 Carácteres.";
                    }

                    if (empty($segundoApellido)) {
                        $faltaSegundoApellido = "*Debes escribir tu Segundo Apellido.";
                    } elseif (strlen($segundoApellido) > 25) {
                        $faltaSegundoApellido = "*El Segundo Apellido que has introducido no puede contener más de 25 Carácteres.";
                    }

                    $fechaActual = date("Y-m-d");
                    $edad = date_diff(date_create($fechaNacimiento), date_create($fechaActual))->y;

                    if (empty($fechaNacimiento)) {
                        $faltaFechaNacimiento = "*Debes introducir tu Fecha de Nacimiento.";
                    } elseif ($edad < 18) {
                        $faltaFechaNacimiento = "*Debes tener al menos 18 años para poder registrarte.";
                    }

                    if (empty($telefono)) {
                        $faltaTelefono = "*Debes escribir tu Número de Teléfono.";
                    } elseif (!preg_match("/^[0-9]{9}$/", $telefono)) {
                        $faltaTelefono = "*El Número de Teléfono que has escrito no es válido.";
                    }

                    if (empty($email)) {
                        $faltaEmail = "*Debes escribir tu Correo Electrónico.";
                    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $faltaEmail = "*El Correo Electrónico que has introducido no es válido.";
                    } elseif (strlen($email) > 50) {
                        $faltaEmail = "*El Correo Electrónico que has introducido no puede contener más de 50 Carácteres.";
                    }

                    if (empty($aceptarTerminos)) {
                        $faltaAceptarTerminos = "*Debes aceptar los Términos de la Política de Privacidad.";
                    }

                    if ((empty($faltaNombre)) && (empty($faltaPrimerApellido)) && (empty($faltaSegundoApellido)) && (empty($faltaFechaNacimiento)) && (empty($faltaTelefono)) && (empty($faltaEmail)) && (empty($faltaAceptarTerminos))) {
                        $consultaActualizarUsuario = "UPDATE clientes
                                                      SET nif = '$dni', nombre = '$nombre', primer_apellido = '$primerApellido', segundo_apellido = '$segundoApellido', fecha_nacimiento = '$fechaNacimiento', telefono = '$telefono', email = '$email', rol = '$rol'
                                                      WHERE clientes.nif = '$dni'";
                        $resultadoConsultaActualizarUsuario = mysqli_query($enlace, $consultaActualizarUsuario);

                        if ($resultadoConsultaActualizarUsuario) {
                            $destinatario = $email;
                            $encabezado = 'LINEASPASE';
                            $cuerpoMensaje = 'Le comunicamos que sus Datos han sido modificados según lo indicado. Si tiene alguna duda póngase en contacto a través de nuestra Página Web' . "\r\n" . 'Un saludo.';
                            $headers = 'From: lineaspase@lineaspase.com' . "\r\n" .
                                       'Reply-To: lineaspase@lineaspase.com' . "\r\n" .
                                       'X-Mailer: PHP/' . phpversion();
                            mail($destinatario, $encabezado, $cuerpoMensaje, $headers);

                            $mensajeUsuarioModificado = "Se han modificado los Datos del Usuario.";
                        } else {
                            $mensajeUsuarioNoModificado = "*En estos momentos no ha sido posible modificar los Datos del Usuario. Por favor, inténtelo de nuevo más tarde o póngase en contacto con el Administrador de la Base de Datos.";
                        }
                    }
                }
            ?>

            <form method="POST" action="<?php echo limpiarCaracteres($_SERVER["PHP_SELF"]); ?>">
                <label for="nombre">Nombre:</label>
                <input type="text" name="nombre" id="nombre" maxlength="25" value="<?php echo $nombre; ?>" placeholder="Escribe aquí el Nombre.">
                <?php
                    if (!empty($faltaNombre)) {
                        echo '<span class="faltanCampos">' . $faltaNombre . '</span> <br>';
                    }
                ?>

                <label for="primerApellido">Primer Apellido:</label>
                <input type="text" name="primerApellido" id="primerApellido" maxlength="25" value="<?php echo $primerApellido; ?>" placeholder="Escribe aquí el Primer Apellido.">
                <?php
                    if (!empty($faltaPrimerApellido)) {
                        echo '<span class="faltanCampos">' . $faltaPrimerApellido . '</span> <br>';
                    }
                ?>

                <label for="segundoApellido">Segundo Apellido:</label>
                <input type="text" name="segundoApellido" id="segundoApellido" maxlength="25" value="<?php echo $segundoApellido; ?>" placeholder="Escribe aquí el Segundo Apellido.">
                <?php
                    if (!empty($faltaSegundoApellido)) {
                        echo '<span class="faltanCampos">' . $faltaSegundoApellido . '</span> <br>';
                    }
                ?>

                <label for="dni">DNI:</label>
                <input type="text" name="dni" id="dni" maxlength="9" value="<?php echo $dni; ?>" placeholder="Escribe aquí el DNI." readonly>
                <?php
                    if (!empty($faltaDni)) {
                        echo '<span class="faltanCampos">' . $faltaDni . '</span> <br>';
                    }
                ?>

                <label for="fechaNacimiento">Fecha de Nacimiento:</label>
                <input type="date" name="fechaNacimiento" id="fechaNacimiento" value="<?php echo $fechaNacimiento; ?>"> <br>
                <?php
                    if (!empty($faltaFechaNacimiento)) {
                        echo '<span class="faltanCampos">' . $faltaFechaNacimiento . '</span> <br>';
                        echo '<style>form input[type="date"]{margin-top: 15px;}</style>';
                    }
                ?>

                <label for="telefono">Teléfono:</label>
                <input type="tel" name="telefono" id="telefono" maxlength="9" value="<?php echo $telefono; ?>" placeholder="Escribe aquí el Número de Teléfono." onkeypress="return soloNumeros(event)"> <br>
                <?php
                    if (!empty($faltaTelefono)) {
                        echo '<span class="faltanCampos">' . $faltaTelefono . '</span> <br>';
                    }
                ?>

                <label for="email">Correo Electrónico:</label>
                <input type="email" name="email" id="email" maxlength="50" value="<?php echo $email; ?>" placeholder="Escribe aquí el Correo Electrónico."> <br>
                <?php
                    if (!empty($faltaEmail)) {
                        echo '<span class="faltanCampos">' . $faltaEmail . '</span> <br>';
                    }
                ?>

                <label for="nombreUsuario">Nombre de Usuario</label>
                <input type="text" name="nombreUsuario" id="nombreUsuario" maxlength="20" value="<?php echo $nombreUsuario; ?>" placeholder="Escribe aquí el Nombre de Usuario." readonly> <br>
                <?php
                    if (!empty($faltaNombreUsuario)) {
                        echo '<span class="faltanCampos">' . $faltaNombreUsuario . '</span> <br>';
                    }
                ?>

                    <label for="rol" class="rol">Rol:</label>
                    <select name="rol" id="rol" onchange="mostrarAlertaRolModificadoCrearUsuarios()">
                        <option value="Cliente" <?php if ($rol === 'Cliente') { echo 'selected'; } ?>>Cliente</option>
                        <option value="Administrador" <?php if ($rol === 'Administrador') { echo 'selected'; } ?>>Administrador</option>
                    </select> <br>

                <input type="checkbox" name="aceptarTerminos" id="aceptarTerminos" <?php if ($aceptarTerminos) echo 'checked'; ?> />He leído y estoy de acuerdo con la <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php#aceptoTerminos">Política de Privacidad<a>.</span> <span id="faltaTerminos" class="faltanCampos"></span> <br>
                <?php
                    if (!empty($faltaAceptarTerminos)) {
                        echo '<span class="faltanCampos">' . $faltaAceptarTerminos . '</span> <br>';
                    }
                ?>

                <input type="submit" value="Modificar usuario">

                <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php" class="botonVolver">Cancelar y volver</a> <br>
                <?php
                    if (!empty($mensajeUsuarioModificado)) {
                        echo '<span class="mensajeUsuarioModificado">' . $mensajeUsuarioModificado .'</span>';
                    }

                    if (!empty($mensajeUsuarioNoModificado)) {
                        echo '<span class="mensajeUsuarioNoModificado">' . $mensajeUsuarioNoModificado .'</span>';
                    }
                ?>
            </form>

            </div>
        </main>

        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
    </body>
</html>

<?php
    mysqli_close($enlace);
?>