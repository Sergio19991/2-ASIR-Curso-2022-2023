<?php include "conexionBD.php"; ?>

<?php
    session_start();

    if ((isset($_SESSION['loggedin'])) && ($_SESSION['loggedin'] === true) && ($_SESSION['rol'] === 'Administrador') && (isset($_COOKIE['rol']))) {
        $nombre = $_SESSION["nombre"];
        $nombreUsuario = $_SESSION["nombreUsuario"];
        $primerApellido = $_SESSION["primerApellido"];
        $segundoApellido = $_SESSION["segundoApellido"];
    } else {
        header("Location: iniciarSesion.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lineaspase: Modificar Línea</title>
    <meta autor="© Sergio Bejarano Arroyo">
    <link rel="stylesheet" href="css/modificarLinea.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="img/favicon16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon32x32.png" sizes="32x32" />
    <script src="js/cajasDesplegables.js"></script>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li class="inicio">
                    <a href="https://www.lineaspase.com/areaAdministradores-index.php">Lineas<span>p</span>a<span>s</span>e</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-usuarios.php">USUARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-flota.php" class="paginaActiva">FLOTA</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-rutasHorarios.php">RUTAS Y HORARIOS</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-contacto.php">CONTACTO</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-textosLegales.php">TEXTOS LEGALES</a>
                </li>
                <li>
                    <a href="https://www.lineaspase.com/areaAdministradores-nosotros.php">NOSOTROS</a>
                </li>
                <li class="dropdown" title="<?php echo "$nombre $primerApellido $segundoApellido"?>">
                    <a class="dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo "Bienvenid@ $nombreUsuario";
                        ?>
                    </a>
                    <span class="dropdown-menu" id="spanCerrarSesion">
                            <a class="dropdown-item" id="aCerrarSesion" href="areaAdministradores-misCompras.php" title="Ver mis Compras">Mis Compras</a> <br>
                            <a class="dropdown-item" id="aCerrarSesion" href="cerrarSesion.php" title="Cerrar Sesión">Cerrar sesión</a>
                    </span>
                </li>
            </ul>
        </nav>
    </header>

    <main>
            <div class="contenidoPrincipal">

                <h1 class=flota>MODIFICAR LÍNEA</h1>

                <?php
                    function limpiarCaracteres($datos) {
                        $datos = trim($datos);
                        $datos = stripslashes($datos);
                        $datos = htmlspecialchars($datos);
                        return $datos;
                    }

                    $consultarLocalidades = "SELECT nombre AS 'seleccionarNombreLocalidad', ciudad AS 'seleccionarNombreCiudad'
                                             FROM localidad";
                    $resultadoConsultarLocalidades = mysqli_query($enlace, $consultarLocalidades);

                    $localidades = array();

                    if ($resultadoConsultarLocalidades) {
                        while ($fila = mysqli_fetch_assoc($resultadoConsultarLocalidades)) {
                            $localidades[] = $fila;
                        }
                    }

                    if (isset($_GET['nombreLinea'])) {
                        $nombreLinea = limpiarCaracteres($_GET['nombreLinea']);
                    }

                    $consultarFlota = "SELECT lineas.nombre AS 'nombreLinea', lo.nombre AS 'nombreLocalidadOrigen', lo.ciudad AS 'nombreCiudadOrigen', ld.nombre AS 'nombreLocalidadDestino', ld.ciudad AS 'nombreCiudadDestino', chofers.nombre AS 'nombreChofer', chofers.primer_apellido AS 'primerApellidoChofer', chofers.segundo_apellido AS 'segundoApellidoChofer', chofers.nif AS 'dniChofer', autobuses.matricula AS 'matriculaAutobus', autobuses.marca AS 'marcaAutobus', autobuses.modelo AS 'modeloAutobus', pertenecer.fecha_entrada AS 'fechaEntradaRuta', pertenecer.fecha_salida AS 'fechaSalidaRuta'
                                       FROM lineas
                                       JOIN pertenecer ON lineas.codigo = pertenecer.codigo_linea
                                       JOIN autobuses ON autobuses.matricula = pertenecer.matricula_autobus
                                       JOIN chofers ON chofers.nif = autobuses.nif_chofer
                                       JOIN lineas llo ON llo.codigo = lineas.codigo
                                       JOIN localidad lo ON lo.codigo = llo.localidad_origen
                                       JOIN lineas lld ON lld.codigo = lineas.codigo
                                       JOIN localidad ld ON ld.codigo = lld.localidad_destino
                                       WHERE lineas.nombre LIKE '{$nombreLinea}'";
                    $resultadoConsultarFlota = mysqli_query($enlace, $consultarFlota);

                    if($resultadoConsultarFlota) {
                        $fila = mysqli_fetch_assoc($resultadoConsultarFlota);

                        $nombreLinea = mysqli_real_escape_string($enlace, $fila['nombreLinea']);
                        $nombreLocalidadOrigen = mysqli_real_escape_string($enlace, $fila['nombreLocalidadOrigen']);
                        $nombreCiudadOrigen = mysqli_real_escape_string($enlace, $fila['nombreCiudadOrigen']);
                        $nombreLocalidadDestino = mysqli_real_escape_string($enlace, $fila['nombreLocalidadDestino']);
                        $nombreCiudadDestino = mysqli_real_escape_string($enlace, $fila['nombreCiudadDestino']);
                        $nombreChofer = mysqli_real_escape_string($enlace, $fila['nombreChofer']);
                        $primerApellidoChofer = mysqli_real_escape_string($enlace, $fila['primerApellidoChofer']);
                        $segundoApellidoChofer = mysqli_real_escape_string($enlace, $fila['segundoApellidoChofer']);
                        $dniChofer = mysqli_real_escape_string($enlace, $fila['dniChofer']);
                        $matriculaAutobus = mysqli_real_escape_string($enlace, $fila['matriculaAutobus']);
                        $marcaAutobus = mysqli_real_escape_string($enlace, $fila['marcaAutobus']);
                        $modeloAutobus = mysqli_real_escape_string($enlace, $fila['modeloAutobus']);
                        $fechaEntradaRuta = mysqli_real_escape_string($enlace, $fila['fechaEntradaRuta']);
                        $fechaSalidaRuta = mysqli_real_escape_string($enlace, $fila['fechaSalidaRuta']);
                        $codigoLinea = mysqli_real_escape_string($enlace, $fila['codigoLinea']);
                    }

                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            $modificarOrigenL1 = isset($_POST['modificarOrigenL1']) ? $_POST['modificarOrigenL1'] : '';
                            $modificarDestinoL1 = isset($_POST['modificarDestinoL1']) ? $_POST['modificarDestinoL1'] : '';
                            $modificarFechaEntradaRuta = limpiarCaracteres($_POST['modificarFechaEntradaRuta']);
                            $modificarFechaSalidaRuta = limpiarCaracteres($_POST['modificarFechaSalidaRuta']);
                            $mantenerNombreLinea = limpiarCaracteres($_POST['mantenerNombreLinea']);
                             
                            $consultaModificarFechaEntradaRuta = "UPDATE pertenecer
                                                                  JOIN lineas ON pertenecer.codigo_linea = lineas.codigo
                                                                  JOIN autobuses ON pertenecer.matricula_autobus = autobuses.matricula
                                                                  SET pertenecer.fecha_entrada = '{$modificarFechaEntradaRuta}'
                                                                  WHERE lineas.nombre LIKE '{$nombreLinea}'";
                            $consultaModificarFechaSalidaRuta = "UPDATE pertenecer
                                                                 JOIN lineas ON pertenecer.codigo_linea = lineas.codigo
                                                                 JOIN autobuses ON pertenecer.matricula_autobus = autobuses.matricula
                                                                 SET pertenecer.fecha_salida = '{$modificarFechaSalidaRuta}'
                                                                 WHERE lineas.nombre LIKE 'L-1'";
                            $consultaModificarOrigen = "UPDATE lineas SET localidad_origen = (SELECT codigo FROM localidad WHERE nombre = '$modificarOrigenL1') WHERE nombre LIKE '{$nombreLinea}'";
                            $consultaModificarDestino = "UPDATE lineas SET localidad_destino = (SELECT codigo FROM localidad WHERE nombre = '$modificarDestinoL1') WHERE nombre LIKE '{$nombreLinea}'";

                            $resultadoConsultaModificarFechaEntradaRuta = mysqli_query($enlace, $consultaModificarFechaEntradaRuta);
                            $resultadoConsultaModificarFechaSalidaRuta = mysqli_query($enlace, $consultaModificarFechaSalidaRuta);
                            $resultadoConsultaModificarOrigen = mysqli_query($enlace, $consultaModificarOrigen);
                            $resultadoConsultaModificarDestino = mysqli_query($enlace, $consultaModificarDestino);

                            if ($modificarOrigenL1 === $modificarDestinoL1) {
                                $mensajesErroresL1 = "*El origen y el destino no pueden ser iguales.";
                            }

                            if ($modificarFechaEntradaRuta === $modificarFechaSalidaRuta) {
                                $mensajesErroresL1 = "*La Fecha de Entrada en Ruta y la Fecha de Salida en Ruta no pueden ser iguales.";
                            }

                            if ($modificarFechaEntradaRuta > $modificarFechaSalidaRuta) {
                                $mensajesErroresL1 = "*La Fecha de Entrada en Ruta no puede ser superior a la Fecha de Salida en Ruta.";
                            }

                            if ((empty($mensajesErroresL1))) {
                                if ($resultadoConsultaModificarFechaEntradaRuta && $resultadoConsultaModificarFechaEntradaRuta && $resultadoConsultaModificarOrigen && $resultadoConsultaModificarDestino) {
                                    echo "<script>window.location='https://www.lineaspase.com/areaAdministradores-modificarLinea.php?nombreLinea={$mantenerNombreLinea}'</script>";
                                    exit();
                                } else {
                                    $mensajeModificacionIncorrectaL1 = "*En estos momentos no ha sido posible modificar los datos. Por favor, vuelva a intentarlo más tarde o póngase en contacto con el administrador de la base de datos.";
                                }
                            }
                    }
                ?>

                <div class='titulo'> <?php echo "{$nombreLinea}: {$nombreLocalidadOrigen}({$nombreCiudadOrigen}) - {$nombreLocalidadDestino}({$nombreCiudadDestino})" ?> </div>
                    <div class='contenido'>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <input type="hidden" name="mantenerNombreLinea" value="<?php echo $nombreLinea; ?>">
                            <label for="origen">Origen:</label>
                            <select name="modificarOrigenL1" id="modificarOrigenL1">
                                <option value="<?php echo htmlspecialchars($nombreLocalidadOrigen); ?>" <?php if ($modificarOrigenL1 === $nombreLocalidadOrigen) { echo 'selected'; } ?>>
                                    <?php echo "{$nombreLocalidadOrigen}"; ?>
                                </option>
                                <?php foreach ($localidades as $localidad) {
                                    if ($localidad['seleccionarNombreLocalidad'] !== $nombreLocalidadOrigen) {
                                ?>
                                <option value="<?php echo $localidad['seleccionarNombreLocalidad']; ?>" <?php if ($modificarOrigenL1 === $localidad['seleccionarNombreLocalidad']) { echo 'selected'; } ?>> <?php echo "{$localidad['seleccionarNombreLocalidad']}"; ?> </option>
                                <?php }} ?>
                            </select> <br>

                            <label for="destino">Destino:</label>
                            <select name="modificarDestinoL1" id="modificarDestinoL1">
                                <option value="<?php echo htmlspecialchars($nombreLocalidadDestino); ?>" <?php if ($modificarDestinoL1 === $nombreLocalidadDestino) { echo 'selected'; } ?>>
                                    <?php echo "{$nombreLocalidadDestino}"; ?>
                                </option>
                                <?php foreach ($localidades as $localidad) {
                                    if ($localidad['seleccionarNombreLocalidad'] !== $nombreLocalidadDestino) {
                                ?>
                                <option value="<?php echo $localidad['seleccionarNombreLocalidad']; ?>" <?php if ($modificarDestinoL1 === $localidad['seleccionarNombreLocalidad']) { echo 'selected'; } ?>> <?php echo "{$localidad['seleccionarNombreLocalidad']}"; ?> </option>
                                <?php }} ?>
                            </select> <br>

                            <label for="chofer">Chofer:</label>
                            <input type="text" name="chofer" id="chofer" value='<?php echo $nombreChofer . ' ' . $primerApellidoChofer . ' ' . $segundoApellidoChofer . ' (DNI: ' . $dniChofer . ')'; ?>' disabled>
                            <input type="hidden" name="chofer" id="chofer" value='<?php echo $nombreChofer . ' ' . $primerApellidoChofer . ' ' . $segundoApellidoChofer . ' (DNI: ' . $dniChofer . ')'; ?>'>

                            <label for="autobus">Autobús:</label>
                            <input type="text" name="autobus" id="autobus" value='<?php echo $marcaAutobus . ' ' . $modeloAutobus . ' (Matrícula: ' . $matriculaAutobus . ')'; ?>' disabled>
                            <input type="hidden" name="autobus" id="autobus" value='<?php echo $marcaAutobus . ' ' . $modeloAutobus . ' (Matrícula: ' . $matriculaAutobus . ')'; ?>'>

                            <label for="modificarFechaEntradaRuta">Fecha de Entrada en Ruta:</label>
                            <input type="date" name="modificarFechaEntradaRuta" id="modificarFechaEntradaRuta" value='<?php echo $fechaEntradaRuta; ?>'> <br>

                            <label for="modificarFechaSalidaRuta">Fecha de Salida en Ruta:</label>
                            <input type="date" name="modificarFechaSalidaRuta" id="modificarFechaSalidaRuta" value='<?php echo $fechaSalidaRuta; ?>'> <br>

                            <input type="submit" value="Modificar">
                            <a href="https://www.lineaspase.com/areaAdministradores-flota.php" class="botonVolver" title="Volver a Rutas y Horarios">Cancelar y Volver</a> <br>
                            <?php
                                if (!empty($mensajeModificacionIncorrectaL1)) {
                                    echo '<br> <span class="mensajeModificacionIncorrectaL1">' . $mensajeModificacionIncorrectaL1 .'</span>';
                                }

                                if(!empty($mensajesErroresL1)) {
                                    echo '<span class="mensajesErroresL1">'. $mensajesErroresL1 . '</span>';
                                }
                            ?>
                        </form>
                    </div>
                </div>
            </div>
    </main>

        <footer>
            <p>Derechos de autor © 2023 Lineaspase. Todos los derechos reservados.</p>
        </footer>
</body>
</html>

<?php
    mysqli_close($enlace);
?>