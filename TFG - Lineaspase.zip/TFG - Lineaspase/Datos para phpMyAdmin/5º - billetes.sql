INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "20", 1);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "20", 2);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "20", 3);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "20", 4);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "20", 5);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "20", 6);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "20", 7);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "20", 8);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "20", 9);

INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "30", 10);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "30", 11);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "30", 12);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "30", 13);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "30", 14);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "30", 15);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "30", 16);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "30", 17);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("1.50", "30", 18);

INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "50", 19);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "50", 20);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "50", 21);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "50", 22);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "50", 23);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "50", 24);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "50", 25);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "50", 26);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "50", 27);

INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "40", 28);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "40", 29);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "40", 30);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "40", 31);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "40", 32);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "40", 33);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "40", 34);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "40", 35);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("3.99", "40", 36);

INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 37);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 38);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 39);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 40);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 41);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 42);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 43);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 44);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 45);

INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 46);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 47);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 48);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 49);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 50);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 51);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 52);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 53);
INSERT INTO billetes (precio_venta, stock, codigo_linea) VALUES ("2.50", "30", 54);





                        /* © Sergio Bejarano Arroyo */