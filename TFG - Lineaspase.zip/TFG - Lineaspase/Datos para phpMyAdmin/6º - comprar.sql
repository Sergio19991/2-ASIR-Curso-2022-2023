INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-08", 4, 11, "00000000X");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-15", 3, 23, "00000000X");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-16", 10, 28, "00000000X");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-17", 2, 41, "11111111Y");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-18", 1, 32, "11111111Y");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-19", 1, 33, "11111111Y");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-20", 1, 1, "30269879Q");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-21", 2, 43, "30269879Q");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-21", 3, 26, "30269879Q");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-21", 4, 32, "13241515R");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-22", 6, 50, "18232092S");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-23", 8, 40, "81434450Y");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-24", 12, 41, "93851314K");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-25", 3, 51, "81709256P");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-26", 21, 5, "18232092S");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-27", 3, 10, "81434450Y");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-28", 2, 19, "93851314K");
INSERT INTO comprar (fecha_compra, cantidad, codigo_billete, nif_clientes) VALUES ("2023-05-29", 2, 17, "81709256P");





                        /* © Sergio Bejarano Arroyo */