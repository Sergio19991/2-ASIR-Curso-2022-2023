INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 1, "1259PHK");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-01", 2, "1259PHK");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-01", 3, "1259PHK");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-01", 4, "1259PHK");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-01", 5, "1259PHK");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-01", 6, "1259PHK");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-01", 7, "1259PHK");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-01", 8, "1259PHK");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-01", 9, "1259PHK");

INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 10, "1234LPG");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 11, "1234LPG");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 12, "1234LPG");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 13, "1234LPG");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 14, "1234LPG");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 15, "1234LPG");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 16, "1234LPG");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 17, "1234LPG");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 18, "1234LPG");


INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 19, "7895JPN");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 20, "7895JPN");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 21, "7895JPN");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 22, "7895JPN");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 23, "7895JPN");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 24, "7895JPN");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 25, "7895JPN");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 26, "7895JPN");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 27, "7895JPN");

INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 28, "5783JDX");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 29, "5783JDX");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 30, "5783JDX");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 31, "5783JDX");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 32, "5783JDX");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 33, "5783JDX");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 34, "5783JDX");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 35, "5783JDX");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 36, "5783JDX");

INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 37, "3221LMM");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 38, "3221LMM");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 39, "3221LMM");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 40, "3221LMM");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 41, "3221LMM");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 42, "3221LMM");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 43, "3221LMM");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 44, "3221LMM");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 45, "3221LMM");

INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 46, "6999KKL");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 47, "6999KKL");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 48, "6999KKL");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 49, "6999KKL");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 50, "6999KKL");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 51, "6999KKL");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 52, "6999KKL");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 53, "6999KKL");
INSERT INTO pertenecer (fecha_entrada, fecha_salida, codigo_linea, matricula_autobus) VALUES ("2023-01-01", "2023-12-31", 54, "6999KKL");





                        /* © Sergio Bejarano Arroyo */