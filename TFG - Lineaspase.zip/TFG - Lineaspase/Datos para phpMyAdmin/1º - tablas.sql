USE lineaspase;

DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS pertenecer;
DROP TABLE IF EXISTS autobuses;
DROP TABLE IF EXISTS chofers;
DROP TABLE IF EXISTS comprar;
DROP TABLE IF EXISTS billetes;
DROP TABLE IF EXISTS lineas;
DROP TABLE IF EXISTS localidad;
DROP TABLE IF EXISTS clientes;

CREATE TABLE clientes (
    nif VARCHAR(9) PRIMARY KEY,
    nombre VARCHAR(25),
    primer_apellido VARCHAR(25),
    segundo_apellido VARCHAR(25),
    fecha_nacimiento DATE,
    telefono VARCHAR(9),
    email VARCHAR(50),
    nombre_usuario VARCHAR(20),
    contrasena TEXT NOT NULL,
    rol ENUM('Cliente', 'Administrador')
);

CREATE TABLE localidad(
    codigo INT(5) AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(25),
    ciudad VARCHAR(25),
    nombre_estacion VARCHAR(25)
);

CREATE TABLE lineas (
    codigo INT(5) AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(5),
    hora_salida TIME,
    hora_llegada TIME,
    localidad_origen INT(3),
    localidad_destino INT(3),
    CONSTRAINT fk_locorigen_lineas FOREIGN KEY(localidad_origen) REFERENCES localidad (codigo),
    CONSTRAINT fk_locdestino_lineas FOREIGN KEY(localidad_destino) REFERENCES localidad (codigo)
);

CREATE TABLE billetes (
    codigo INT(5) AUTO_INCREMENT PRIMARY KEY,
    precio_venta DECIMAL(3,2),
    stock INT(2),
    codigo_linea INT(3),
    CONSTRAINT fk_codlinea_billetes FOREIGN KEY(codigo_linea) REFERENCES lineas (codigo)
);

CREATE TABLE comprar (
    codigo INT(5) AUTO_INCREMENT PRIMARY KEY,
    fecha_compra DATE,
    cantidad INT(3),
    codigo_billete INT(3),
    nif_clientes VARCHAR(9),
    CONSTRAINT fk_codbillete_comprar FOREIGN KEY(codigo_billete) REFERENCES billetes (codigo),
    CONSTRAINT fk_nif_clientes_comprar FOREIGN KEY(nif_clientes) REFERENCES clientes (nif) ON DELETE SET NULL
);

CREATE TABLE chofers (
    nif VARCHAR(9) PRIMARY KEY,
    nombre VARCHAR(25),
    primer_apellido VARCHAR(25),
    segundo_apellido VARCHAR(25),
    telefono  VARCHAR(9),
    email VARCHAR(50),
    fecha_nacimiento DATE
);

CREATE TABLE autobuses (
    matricula VARCHAR(8) PRIMARY KEY,
    marca VARCHAR(25),
    modelo VARCHAR(25),
    nif_chofer VARCHAR(9),
    CONSTRAINT fk_nif_chofer_autobuses FOREIGN KEY(nif_chofer) REFERENCES chofers (nif)
);

CREATE TABLE pertenecer (
    codigo INT(5) AUTO_INCREMENT PRIMARY KEY,
    fecha_entrada DATE,
    fecha_salida DATE,
    codigo_linea INT(3),
    matricula_autobus VARCHAR(8),
    CONSTRAINT fk_codlinea_pertenecer FOREIGN KEY(codigo_linea) REFERENCES lineas (codigo),
    CONSTRAINT fk_matrautobus_pertencer FOREIGN KEY(matricula_autobus) REFERENCES autobuses (matricula)
);

CREATE TABLE tickets (
    codigo INT(5) AUTO_INCREMENT PRIMARY KEY,
    numero_referencia VARCHAR(6),
    linea VARCHAR(5), 
    localidad_origen VARCHAR(25),
    ciudad_origen VARCHAR(25),
    localidad_destino VARCHAR(25),
    ciudad_destino VARCHAR(25),
    fecha_salida_llegada DATE,
    hora_salida TIME,
    hora_llegada TIME,
    estacion_origen VARCHAR(25),
    estacion_destino VARCHAR(25),
    cantidad INT(3),
    precio DECIMAL(3,2),
    fecha_compra DATE,
    hora_compra TIME,
    nif_clientes VARCHAR(9),
    CONSTRAINT fk_nif_clientes_tickets FOREIGN KEY(nif_clientes) REFERENCES clientes (nif) ON DELETE SET NULL
);





                        /* © Sergio Bejarano Arroyo */