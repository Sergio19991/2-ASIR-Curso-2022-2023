INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("1259PHK", "Volvo", "SC7", "25897568L");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("1234LPG", "Volvo", "SC7", "25698754M");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("7895JPN", "Volvo", "SC7", "96548710K");

INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("5783JDX", "Volvo", "970", "69782056M");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("3221LMM", "Volvo", "970", "48796330B");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("6999KKL", "Volvo", "970", "69587423K");

INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("5973LMT", "Iveco", "Sunrise PMR", "33654879M");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("9855QFR", "Iveco", "Sunrise PMR", "56784304M");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("6925KPP", "Iveco", "Sunrise PMR", "65874301G");

INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("8509JHG", "Glory", "Beulas", "95535469R");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("6300WQE", "Glory", "Beulas", "97224127E");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("8977OJI", "Glory", "Beulas", "82247914Y");

INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("2369JWB", "Irizar", "16", "57772501C");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("5441QCF", "Irizar", "16", "03181220K");
INSERT INTO autobuses (matricula, marca, modelo, nif_chofer) VALUES ("9998NNG", "Irizar", "16", "21346978B");





                        /* © Sergio Bejarano Arroyo */