INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("Osuna", "Sevilla", "La Parcela");
INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("Guillena", "Sevilla", "Plaza Blanca");
INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("Sevilla", "Sevilla", "Plaza de Armas");
INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("San Bernardo", "Cádiz", "Carruaje");
INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("Linares", "Jaén", "Altaje");
INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("Estella", "Pamplona", "Vistrol");
INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("Itero", "Burgos", "Tocuna");
INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("Tabarca", "Alicante", "Blosta");
INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("Uncastillo", "Zaragoza", "Villaina");
INSERT INTO localidad (nombre, ciudad, nombre_estacion) VALUES ("Vigo", "Pontevedra", "La Carta");





                        /* © Sergio Bejarano Arroyo */