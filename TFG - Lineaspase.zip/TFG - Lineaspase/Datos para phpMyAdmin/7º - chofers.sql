INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("25897568L", "Carlos", "García", "Fuentes", "669882334", "cgf@gmail.com", "1970-05-26");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("25698754M", "Juan", "Gutiérrez", "Romero", "698855220", "jgr@gmail.com", "1980-03-16");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("96548710K", "Alba", "Rizado", "Puertas", "693021459", "arp@gmail.com", "1982-11-06");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("69782056M", "Pedro", "Esteban", "Palacios", "656234521", "pep@gmail.com", "1975-01-23");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("48796330B", "Lucía", "Villegas", "Macías", "696322250", "lvm@gmail.com", "1990-06-14");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("69587423K", "Bernardino", "Quesada", "Narváez", "766097562", "bqn@gmail.com", "1985-02-16");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("33654879M", "Aitana", "Marqués", "Blanca", "607715192", "amb@gmail.com", "1988-12-06");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("56784304M", "Odalys", "Calatayud", "Ramirez", "763754043", "ocr@gmail.com", "1980-06-10");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("21346978B", "Rosa", "Franco", "Asensio", "636282950", "rfa@gmail.com", "1998-02-03");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("65874301G", "Ángela", "Galán", "Palomino", "637172034", "agp@gmail.com", "2000-02-10");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("95535469R", "Abigaíl", "Prats", "Abellán", "679961648", "apa@gmail.com", "1963-05-08");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("97224127E", "Ruperta", "Cortés", "Ramirez", "761994750", "rcr@gmail.com", "1967-06-28");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("82247914Y", "Valentina", "Barreda", "Ruiz", "759962153", "vbr@gmail.com", "1982-10-29");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("57772501C", "Dorotea", "Gargallo", "Mesa", "785599593", "dgm@gmail.com", "1960-06-21");
INSERT INTO chofers (nif, nombre, primer_apellido, segundo_apellido, telefono, email, fecha_nacimiento) VALUES ("03181220K", "Luciano", "Tamayo", "Carlos", "785599593", "ltc@gmail.com", "1992-11-02");





                        /* © Sergio Bejarano Arroyo */