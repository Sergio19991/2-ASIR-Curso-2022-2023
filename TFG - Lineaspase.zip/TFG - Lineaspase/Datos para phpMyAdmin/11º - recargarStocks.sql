DROP EVENT IF EXISTS recargarSotck;

CREATE EVENT recargarSotck
ON SCHEDULE
    EVERY 1 WEEK
    STARTS (DATE(NOW()) + INTERVAL (7 - WEEKDAY(NOW())) DAY)
DO
UPDATE billetes
SET billetes.stock = 30;





                        /* © Sergio Bejarano Arroyo */