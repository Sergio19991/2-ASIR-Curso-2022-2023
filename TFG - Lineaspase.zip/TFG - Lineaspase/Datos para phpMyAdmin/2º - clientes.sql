INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ("00000000X", "Administrador", "Administrador", "Administrador", "0000-00-00", "000000000", "admin@gmail.com", "admin", "21232f297a57a5a743894a0e4a801fc3", "Administrador");
INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ("11111111Y", "Sergio", "Bejarano", "Arroyo", "1999-02-03", "652234987", "sergiobejarano99@iesamachado.org", "sergiobejarano99", "da0cc01f9642d87f83fee19f59cb19f4", "Cliente");
INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ("30269879Q", "Marco", "Moran", "Recio", "2000-04-11", "639684561", "pablodominguez00@iesamachado.org", "pablodominguez00", "8a50cbacfef897af9362a990a331a98e", "Cliente");
INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ("13241515R", "Maria", "Saiz", "Mateu", "1985-12-17", "613723165", "mariasaiz_85@gmail.com", "mariasaiz_85", "95eeb4e6ca1af69d98c1b786de1702cb", "Cliente");
INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ("18232092S", "Marti", "Crespo", "Guzman", "1954-12-25", "639686248", "marticrespo_25@gmail.com", "marticrespo_25", "af4b7cc7dff88a0689456c1129fa7d43", "Cliente");
INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ("81434450Y", "Lucas", "Madrid", "Moran", "1974-05-28", "638397317", "lucasmadrid_28@gmail.com", "lucasmadrid_28", "0ef984a42d361c438d5fe1051702b6e5", "Cliente");
INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ("93851314K", "Sandra", "Marco", "Lafuente", "2001-01-04", "708929349", "sandramarco_04@gmail.com", "sandramarco_04", "62ec53eebcfab43efac282205f81f5d0", "Cliente");
INSERT INTO clientes (nif, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, email, nombre_usuario, contrasena, rol) VALUES ("81709256P", "Elisabeth", "Recio", "Guerra", "2000-01-08", "671461747", "elisabethrecio_08@gmail.com", "elisabethrecio_08", "f449a2d9068cb62b6ca6d7f3c6dcb333", "Cliente");





                        /* © Sergio Bejarano Arroyo */