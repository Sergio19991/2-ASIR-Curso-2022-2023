INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-1", "07:15:00", "07:45:00", 3, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-1", "08:00:00", "08:30:00", 3, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-1", "09:30:00", "10:00:00", 3, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-1", "10:00:00", "10:30:00", 3, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-1", "12:00:00", "12:30:00", 3, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-1", "13:00:00", "13:30:00", 3, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-1", "14:00:00", "14:30:00", 3, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-1", "19:00:00", "19:30:00", 3, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-1", "20:00:00", "20:30:00", 3, 2);

INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-2", "07:15:00", "07:45:00", 4, 6);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-2", "08:00:00", "08:30:00", 4, 6);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-2", "09:30:00", "10:00:00", 4, 6);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-2", "10:00:00", "10:30:00", 4, 6);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-2", "12:00:00", "12:30:00", 4, 6);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-2", "13:00:00", "13:30:00", 4, 6);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-2", "14:00:00", "14:30:00", 4, 6);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-2", "19:00:00", "19:30:00", 4, 6);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-2", "20:00:00", "20:30:00", 4, 6);

INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-3", "06:00:00", "08:00:00", 1, 5);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-3", "08:00:00", "10:00:00", 1, 5);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-3", "10:00:00", "12:00:00", 1, 5);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-3", "13:15:00", "15:15:00", 1, 5);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-3", "15:00:00", "17:00:00", 1, 5);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-3", "16:30:00", "18:30:00", 1, 5);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-3", "17:45:00", "19:45:00", 1, 5);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-3", "20:00:00", "22:00:00", 1, 5);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-3", "22:30:00", "00:30:00", 1, 5);

INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-4", "06:00:00", "08:00:00", 7, 9);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-4", "08:00:00", "10:00:00", 7, 9);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-4", "10:00:00", "12:00:00", 7, 9);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-4", "13:15:00", "15:15:00", 7, 9);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-4", "15:00:00", "17:00:00", 7, 9);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-4", "16:30:00", "18:30:00", 7, 9);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-4", "17:45:00", "19:45:00", 7, 9);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-4", "20:00:00", "22:00:00", 7, 9);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-4", "22:30:00", "00:30:00", 7, 9);

INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-5", "09:00:00", "10:30:00", 8, 10);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-5", "10:00:00", "11:30:00", 8, 10);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-5", "10:15:00", "11:45:00", 8, 10);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-5", "13:00:00", "14:30:00", 8, 10);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-5", "13:30:00", "15:00:00", 8, 10);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-5", "15:30:00", "17:00:00", 8, 10);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-5", "17:30:00", "19:00:00", 8, 10);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-5", "18:30:00", "20:00:00", 8, 10);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-5", "20:00:00", "21:30:00", 8, 10);

INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-6", "09:00:00", "10:30:00", 1, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-6", "10:00:00", "11:30:00", 1, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-6", "10:15:00", "11:45:00", 1, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-6", "13:00:00", "14:30:00", 1, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-6", "13:30:00", "15:00:00", 1, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-6", "15:30:00", "17:00:00", 1, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-6", "17:30:00", "19:00:00", 1, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-6", "18:30:00", "20:00:00", 1, 2);
INSERT INTO lineas (nombre, hora_salida, hora_llegada, localidad_origen, localidad_destino) VALUES ("L-6", "20:00:00", "21:30:00", 1, 2);





                        /* © Sergio Bejarano Arroyo */